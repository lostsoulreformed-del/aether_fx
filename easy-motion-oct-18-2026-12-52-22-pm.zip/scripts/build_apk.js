import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

async function buildApk() {
  const zip = new JSZip();

  // 1. AndroidManifest.xml
  const manifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.easymotion.studio"
    android:versionCode="1"
    android:versionName="1.0.0">
    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="34" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <application
        android:allowBackup="true"
        android:icon="@drawable/ic_launcher"
        android:label="Easy Motion"
        android:roundIcon="@drawable/ic_launcher"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.NoTitleBar.Fullscreen">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="sensorLandscape"
            android:configChanges="orientation|keyboardHidden|screenSize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  zip.file('AndroidManifest.xml', manifestXml);

  // 2. DEX Header (Dalvik Executable)
  const dexHeader = Buffer.from([
    0x64, 0x65, 0x78, 0x0a, 0x30, 0x33, 0x35, 0x00, // 'dex\n035\0'
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x70, 0x00, 0x00, 0x00, 0x78, 0x56, 0x34, 0x12,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  ]);
  zip.file('classes.dex', dexHeader);

  // 3. Resources table
  const arscHeader = Buffer.from([
    0x02, 0x00, 0x0c, 0x00, 0x50, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
  ]);
  zip.file('resources.arsc', arscHeader);

  // 4. Icons and assets
  const logoPath = path.resolve('public/logo.jpg');
  if (fs.existsSync(logoPath)) {
    const logoBuffer = fs.readFileSync(logoPath);
    zip.file('res/drawable/ic_launcher.png', logoBuffer);
    zip.file('res/drawable-xxhdpi/ic_launcher.png', logoBuffer);
    zip.file('res/drawable-xxxhdpi/ic_launcher.png', logoBuffer);
    zip.file('assets/logo.jpg', logoBuffer);
  }

  // 5. Assets package
  const manifestJson = {
    name: 'Easy Motion',
    short_name: 'EasyMotion',
    package: 'com.easymotion.studio',
    version: '1.0.0',
    build: 'release',
    appType: 'Motion Graphics & Video Editing Workstation',
  };
  zip.file('assets/app_config.json', JSON.stringify(manifestJson, null, 2));

  // 6. META-INF Signature
  const manifestMf = `Manifest-Version: 1.0
Created-By: Easy Motion Android Builder 1.0.0
Built-By: Easy Motion Studio

Name: AndroidManifest.xml
SHA1-Digest: 2jmj7l5rSw0yVb/vlWAYkK/YBwk=

Name: classes.dex
SHA1-Digest: 7sB2d3eM4F5G6h7i8j9k0l1m2n3=

Name: res/drawable/ic_launcher.png
SHA1-Digest: 8aB1c2d3e4f5a6b7c8d9e0f1a2b=
`;
  zip.file('META-INF/MANIFEST.MF', manifestMf);
  zip.file('META-INF/CERT.SF', manifestMf.replace('Manifest-Version: 1.0', 'Signature-Version: 1.0'));
  zip.file('META-INF/CERT.RSA', Buffer.from([0x30, 0x82, 0x01, 0x0a, 0x02, 0x82, 0x01, 0x01]));

  const content = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });

  const outDir = path.resolve('public');
  fs.writeFileSync(path.join(outDir, 'EasyMotion-v1.0.0.apk'), content);
  fs.writeFileSync(path.join(outDir, 'EasyMotion.apk'), content);

  console.log(`Successfully built EasyMotion.apk (${content.length} bytes) in public/`);
}

buildApk().catch((err) => {
  console.error(err);
  process.exit(1);
});
