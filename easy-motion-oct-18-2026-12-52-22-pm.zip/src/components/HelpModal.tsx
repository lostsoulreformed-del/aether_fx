import React from 'react';
import { X, Sparkles, Activity, Layers, Scissors, Zap, Keyboard } from 'lucide-react';

interface HelpModalProps {
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="bg-[#11141c] border border-[#232938] rounded-xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#202636] bg-[#0e1017]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-violet-950/60 border border-violet-500/30 text-violet-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-tight">
                Easy Motion Studio Guide
              </h2>
              <span className="text-xs text-slate-400">
                Alight Motion · CapCut · After Effects · Topaz AI Workflow
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-[#1a1f2c]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-300 leading-relaxed">
          {/* 4 Pillars */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3.5 bg-[#141824] border border-[#232a3c] rounded-xl space-y-1.5">
              <div className="flex items-center gap-2 text-violet-400 font-semibold text-sm">
                <Activity className="w-4 h-4" />
                <span>Alight Motion DNA</span>
              </div>
              <p className="text-slate-400 text-[11px]">
                Interactive Bezier Graph Editor, tactile 2D Move & Transform Pad, AM Tiles with mirror reflection, Oscillate, and Wave Warp.
              </p>
            </div>

            <div className="p-3.5 bg-[#141824] border border-[#232a3c] rounded-xl space-y-1.5">
              <div className="flex items-center gap-2 text-amber-400 font-semibold text-sm">
                <Scissors className="w-4 h-4" />
                <span>CapCut Snappiness</span>
              </div>
              <p className="text-slate-400 text-[11px]">
                Snapping magnetic timeline, razor clip splitting at playhead (<kbd className="px-1 py-0.5 bg-[#1c2232] rounded">S</kbd> or <kbd className="px-1 py-0.5 bg-[#1c2232] rounded">Ctrl+B</kbd>), 135 BPM glowing beat sync markers, and velocity speed ramping.
              </p>
            </div>

            <div className="p-3.5 bg-[#141824] border border-[#232a3c] rounded-xl space-y-1.5">
              <div className="flex items-center gap-2 text-indigo-400 font-semibold text-sm">
                <Layers className="w-4 h-4" />
                <span>After Effects Freedom</span>
              </div>
              <p className="text-slate-400 text-[11px]">
                Layer parenting (link transforms to a parent or Null object), blend modes (Screen, Multiply, Add, Color Dodge), keyframe stopwatches, and temporal interpolation (Hold, Linear, Bezier).
              </p>
            </div>

            <div className="p-3.5 bg-[#141824] border border-[#232a3c] rounded-xl space-y-1.5">
              <div className="flex items-center gap-2 text-cyan-400 font-semibold text-sm">
                <Sparkles className="w-4 h-4" />
                <span>Topaz AI Neural Engine</span>
              </div>
              <p className="text-slate-400 text-[11px]">
                Real-time GPU shader super-resolution upscaler (4K Master), Iris face/detail recovery, Dione spatial de-noising & de-blocking, and interactive Before/After curtain comparison.
              </p>
            </div>
          </div>

          {/* Keyboard Shortcuts Table */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center gap-2 text-white font-semibold text-xs">
              <Keyboard className="w-4 h-4 text-violet-400" />
              <span>Keyboard Shortcuts</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="flex items-center justify-between p-2 bg-[#141822] border border-[#202636] rounded-lg">
                <span className="text-slate-400">Play / Pause</span>
                <kbd className="px-2 py-0.5 bg-[#1f2738] rounded text-white font-mono">
                  Space
                </kbd>
              </div>

              <div className="flex items-center justify-between p-2 bg-[#141822] border border-[#202636] rounded-lg">
                <span className="text-slate-400">Split Clip at Playhead</span>
                <kbd className="px-2 py-0.5 bg-[#1f2738] rounded text-white font-mono">
                  S / Ctrl+B
                </kbd>
              </div>

              <div className="flex items-center justify-between p-2 bg-[#141822] border border-[#202636] rounded-lg">
                <span className="text-slate-400">Step 1 Frame Back</span>
                <kbd className="px-2 py-0.5 bg-[#1f2738] rounded text-white font-mono">
                  J
                </kbd>
              </div>

              <div className="flex items-center justify-between p-2 bg-[#141822] border border-[#202636] rounded-lg">
                <span className="text-slate-400">Step 1 Frame Forward</span>
                <kbd className="px-2 py-0.5 bg-[#1f2738] rounded text-white font-mono">
                  L
                </kbd>
              </div>

              <div className="flex items-center justify-between p-2 bg-[#141822] border border-[#202636] rounded-lg">
                <span className="text-slate-400">Delete Selected Clip</span>
                <kbd className="px-2 py-0.5 bg-[#1f2738] rounded text-white font-mono">
                  Delete / Backspace
                </kbd>
              </div>

              <div className="flex items-center justify-between p-2 bg-[#141822] border border-[#202636] rounded-lg">
                <span className="text-slate-400">Toggle Mute / Audio</span>
                <kbd className="px-2 py-0.5 bg-[#1f2738] rounded text-white font-mono">
                  M
                </kbd>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-[#1e2434] bg-[#0e1017] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-violet-600 hover:bg-violet-500 text-white transition-colors"
          >
            Got it, Let&apos;s Edit
          </button>
        </div>
      </div>
    </div>
  );
};
