import React from 'react';
import {
  Sparkles,
  Cpu,
  Layers,
  Split,
  Maximize2,
  Zap,
  Sliders,
  Check,
  RotateCcw,
} from 'lucide-react';
import { TopazModel, TopazSettings } from '../types/editor';
import { TOPAZ_PRESETS } from '../utils/presets';

interface TopazLaboratoryProps {
  settings: TopazSettings;
  onUpdateSettings: (newSettings: Partial<TopazSettings>) => void;
  onClose?: () => void;
}

export const TopazLaboratory: React.FC<TopazLaboratoryProps> = ({
  settings,
  onUpdateSettings,
  onClose,
}) => {
  const models: Array<{
    id: TopazModel;
    name: string;
    description: string;
    badge: string;
  }> = [
    {
      id: 'proteus-v4',
      name: 'Proteus v4 Auto',
      description: 'Neural edge reconstruction & deep super-resolution 4K upscaling',
      badge: 'All-Rounder',
    },
    {
      id: 'iris-face',
      name: 'Iris Face & Detail',
      description: 'Face micro-texture recovery, eye clarity, and skin tone enhancement',
      badge: 'Portraits & Subjects',
    },
    {
      id: 'chronos-60fps',
      name: 'Chronos Optical Flow',
      description: 'Motion vector frame interpolation for buttery 60fps smooth slow-mo',
      badge: 'Velocity Ramps',
    },
    {
      id: 'dione-dehalo',
      name: 'Dione De-Halo & Clean',
      description: 'Artifact suppression, compression de-blocking and spatial de-noise',
      badge: 'Low-Light & Clean',
    },
    {
      id: 'gaia-hq',
      name: 'Gaia 35mm Master',
      description: 'Organic silver halide film grain synthesis with cinematic grading',
      badge: 'Cinematic Grain',
    },
  ];

  const applyPreset = (presetKey: string) => {
    const preset = TOPAZ_PRESETS[presetKey];
    if (preset) {
      onUpdateSettings(preset);
    }
  };

  return (
    <div className="bg-[#10131a] border border-[#222837] rounded-xl p-5 shadow-2xl w-full max-w-3xl select-none text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-[#202636]">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-cyan-950/60 border border-cyan-500/30 text-cyan-400">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white tracking-tight">
                Topaz Neural Enhancement Engine
              </h2>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                GPU Shader Pipeline
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Super-resolution 4K upscaler, Iris detail recovery, and Chronos optical flow
            </p>
          </div>
        </div>

        {/* Master ON/OFF Switch */}
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 cursor-pointer">
            <span className="text-xs font-medium text-slate-300">
              {settings.enabled ? 'Active' : 'Bypassed'}
            </span>
            <input
              type="checkbox"
              checked={settings.enabled}
              onChange={(e) => onUpdateSettings({ enabled: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-10 h-5 bg-[#1b202c] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-500" />
          </label>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 mt-4">
        {/* Left: Model Architecture & Presets (5 cols) */}
        <div className="md:col-span-5 space-y-4">
          <div>
            <span className="text-xs font-semibold text-slate-300">
              Neural AI Models
            </span>
            <div className="mt-2 space-y-1.5">
              {models.map((m) => (
                <button
                  key={m.id}
                  onClick={() => onUpdateSettings({ model: m.id })}
                  className={`w-full text-left p-2.5 rounded-lg border transition-all ${
                    settings.model === m.id
                      ? 'bg-cyan-950/40 border-cyan-500/60 shadow-xs'
                      : 'bg-[#151923] border-[#202737] hover:border-slate-600 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-semibold ${
                        settings.model === m.id ? 'text-cyan-300' : 'text-slate-200'
                      }`}
                    >
                      {m.name}
                    </span>
                    <span className="text-[10px] text-cyan-400/80 bg-cyan-950 px-1.5 py-0.5 rounded">
                      {m.badge}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {m.description}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Quick Presets */}
          <div>
            <span className="text-xs font-semibold text-slate-300">
              One-Click Presets
            </span>
            <div className="grid grid-cols-2 gap-1.5 mt-2">
              <button
                onClick={() => applyPreset('proteus-auto')}
                className="px-2.5 py-1.5 text-xs text-left bg-[#141822] hover:bg-[#1b212f] border border-[#22293b] rounded-md transition-colors"
              >
                Auto Crisp 4K
              </button>
              <button
                onClick={() => applyPreset('iris-face')}
                className="px-2.5 py-1.5 text-xs text-left bg-[#141822] hover:bg-[#1b212f] border border-[#22293b] rounded-md transition-colors"
              >
                Iris Face Boost
              </button>
              <button
                onClick={() => applyPreset('chronos-smooth')}
                className="px-2.5 py-1.5 text-xs text-left bg-[#141822] hover:bg-[#1b212f] border border-[#22293b] rounded-md transition-colors"
              >
                Chronos 60FPS
              </button>
              <button
                onClick={() => applyPreset('theatrical-35mm')}
                className="px-2.5 py-1.5 text-xs text-left bg-[#141822] hover:bg-[#1b212f] border border-[#22293b] rounded-md transition-colors"
              >
                35mm Film Grain
              </button>
            </div>
          </div>
        </div>

        {/* Right: Fine-Tuning Parameters & Split Curtain (7 cols) */}
        <div className="md:col-span-7 space-y-4">
          {/* Split Screen Curtain Controls */}
          <div className="p-3 bg-[#131722] border border-[#22293b] rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Split className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-semibold text-white">
                  Split-Screen Curtain Comparison
                </span>
              </div>
              <button
                onClick={() => onUpdateSettings({ splitView: !settings.splitView })}
                className={`px-2 py-0.5 text-xs rounded font-medium transition-colors ${
                  settings.splitView
                    ? 'bg-cyan-500 text-slate-950 font-semibold'
                    : 'bg-[#1b212f] text-slate-400 hover:text-slate-200'
                }`}
              >
                {settings.splitView ? 'Curtain ON' : 'Full Preview'}
              </button>
            </div>

            {settings.splitView && (
              <div className="space-y-1 mt-2">
                <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                  <span>Source (1080p)</span>
                  <span className="text-cyan-400">{settings.splitPosition}% Curtain</span>
                  <span>Topaz 4K</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="95"
                  value={settings.splitPosition}
                  onChange={(e) =>
                    onUpdateSettings({ splitPosition: Number(e.target.value) })
                  }
                  className="w-full accent-cyan-400 h-1.5 bg-[#1f2637] rounded-lg cursor-pointer"
                />
              </div>
            )}
          </div>

          {/* Upscale Target */}
          <div className="flex items-center justify-between p-2.5 bg-[#131722] border border-[#22293b] rounded-lg">
            <span className="text-xs text-slate-300 font-medium">Output Upscale Target</span>
            <div className="flex gap-1">
              {(['1080p', '2k', '4k', '8k'] as const).map((res) => (
                <button
                  key={res}
                  onClick={() => onUpdateSettings({ upscaleTarget: res })}
                  className={`px-2.5 py-1 text-xs font-mono font-medium rounded transition-colors ${
                    settings.upscaleTarget === res
                      ? 'bg-cyan-500 text-slate-950 font-bold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-[#1b212f]'
                  }`}
                >
                  {res.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          {/* Parameter Sliders */}
          <div className="space-y-3 p-3 bg-[#131722] border border-[#22293b] rounded-lg">
            {/* Sharpening */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Neural Sharpening</span>
                <span className="font-mono text-cyan-400">{settings.sharpen}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.sharpen}
                onChange={(e) =>
                  onUpdateSettings({ sharpen: Number(e.target.value) })
                }
                className="w-full accent-cyan-400 h-1.5 bg-[#1f2637] rounded-lg cursor-pointer"
              />
            </div>

            {/* Recover Details */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Micro-Detail Recovery (Iris)</span>
                <span className="font-mono text-cyan-400">
                  {settings.recoverDetails}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.recoverDetails}
                onChange={(e) =>
                  onUpdateSettings({ recoverDetails: Number(e.target.value) })
                }
                className="w-full accent-cyan-400 h-1.5 bg-[#1f2637] rounded-lg cursor-pointer"
              />
            </div>

            {/* De-Noise */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Spatial De-Noise (Dione)</span>
                <span className="font-mono text-cyan-400">{settings.deNoise}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.deNoise}
                onChange={(e) =>
                  onUpdateSettings({ deNoise: Number(e.target.value) })
                }
                className="w-full accent-cyan-400 h-1.5 bg-[#1f2637] rounded-lg cursor-pointer"
              />
            </div>

            {/* Film Grain */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Organic 35mm Film Grain</span>
                <span className="font-mono text-cyan-400">
                  {settings.grainAmount}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.grainAmount}
                onChange={(e) =>
                  onUpdateSettings({ grainAmount: Number(e.target.value) })
                }
                className="w-full accent-cyan-400 h-1.5 bg-[#1f2637] rounded-lg cursor-pointer"
              />
            </div>

            {/* Chronos 60fps smoothing checkbox */}
            <div className="pt-2 border-t border-[#1f2637] flex items-center justify-between">
              <div className="text-xs">
                <div className="font-medium text-slate-200">
                  Chronos 60FPS Frame Interpolation
                </div>
                <div className="text-[11px] text-slate-400">
                  Sub-frame motion smoothing for slow-mo ramps
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.opticalFlowSmooth}
                onChange={(e) =>
                  onUpdateSettings({ opticalFlowSmooth: e.target.checked })
                }
                className="w-4 h-4 accent-cyan-500 rounded bg-[#1f2637] cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
