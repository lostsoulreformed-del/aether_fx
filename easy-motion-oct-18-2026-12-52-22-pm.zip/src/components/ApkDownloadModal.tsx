import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  Check,
  X,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface ApkDownloadModalProps {
  onClose: () => void;
}

export const ApkDownloadModal: React.FC<ApkDownloadModalProps> = ({ onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [downloadStarted, setDownloadStarted] = useState(false);

  const handleInstallClick = async () => {
    if (isInstallable) {
      await install();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="bg-[#0e1017] border border-[#242b3c] rounded-2xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#1c2232] bg-[#0a0c12]">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-yellow-400" />
            <h2 className="text-sm font-bold text-white tracking-tight">
              Download Easy Motion APK
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-[#1a1f2c]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Logo & App Info */}
        <div className="p-5 flex flex-col items-center text-center space-y-3 bg-gradient-to-b from-[#131622] to-[#0e1017]">
          <div className="relative w-20 h-20 rounded-2xl overflow-hidden shadow-2xl border-2 border-yellow-400 p-0.5 bg-black">
            <img
              src="/logo.jpg"
              alt="Easy Motion Logo"
              className="w-full h-full object-cover rounded-[14px]"
            />
          </div>

          <div>
            <h3 className="text-base font-bold text-white tracking-tight flex items-center justify-center gap-1.5">
              <span>Easy Motion</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-yellow-400/20 text-yellow-300 border border-yellow-400/40">
                v1.0.0
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-1 max-w-xs">
              Direct Android APK package with Bezier velocity curves, multi-track magnetic timeline, and Topaz AI quality.
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs font-mono text-slate-400 pt-1">
            <span className="flex items-center gap-1 text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              Verified APK
            </span>
            <span>·</span>
            <span>2.2 MB</span>
            <span>·</span>
            <span>Android 8.0+</span>
          </div>
        </div>

        {/* Direct Download Actions */}
        <div className="p-5 space-y-3 border-t border-[#1d2334] bg-[#0a0c12]">
          {/* PRIMARY: Direct APK File Download Link */}
          <a
            href="/EasyMotion.apk"
            download="EasyMotion-v1.0.0.apk"
            onClick={() => setDownloadStarted(true)}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-sm font-bold bg-yellow-400 hover:bg-yellow-300 text-slate-950 shadow-lg shadow-yellow-400/20 transition-all active:scale-[0.98]"
          >
            <Download className="w-4 h-4 text-slate-950" />
            <span>Download EasyMotion.apk (2.2 MB)</span>
          </a>

          {downloadStarted && (
            <div className="p-2.5 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-center text-xs text-emerald-300 flex items-center justify-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>APK download started! Open downloads on your device to install.</span>
            </div>
          )}

          {/* SECONDARY: WebAPK Install Prompt if supported */}
          {isInstallable && (
            <button
              onClick={handleInstallClick}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-semibold bg-[#171b26] hover:bg-[#202737] border border-[#273042] text-slate-200 transition-colors"
            >
              <Smartphone className="w-3.5 h-3.5 text-yellow-400" />
              <span>Direct One-Tap Install (WebAPK)</span>
            </button>
          )}

          {/* Easy Instructions */}
          <div className="p-3 bg-[#11141e] border border-[#1e2535] rounded-xl text-[11px] text-slate-400 space-y-1">
            <span className="font-semibold text-slate-300">Quick Android Install Tip:</span>
            <p>
              1. Tap <strong>Download EasyMotion.apk</strong> above.<br />
              2. In your notification bar or file manager, tap <strong>EasyMotion.apk</strong> to install directly!
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-[#1a1f2c] bg-[#080a0f] flex items-center justify-between text-[11px] text-slate-500">
          <span>Package: com.easymotion.studio</span>
          <button
            onClick={onClose}
            className="px-3 py-1 rounded-md text-slate-400 hover:text-white hover:bg-[#161a25]"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
