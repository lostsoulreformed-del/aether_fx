import React, { useRef, useState, useEffect } from 'react';
import {
  Scissors,
  Copy,
  Trash2,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Plus,
  ZoomIn,
  ZoomOut,
  Magnet,
  Diamond,
  Activity,
  Layers,
  Music,
  Video,
  Type,
  Square,
  Sparkles,
} from 'lucide-react';
import {
  Layer,
  Keyframe,
  KeyframableProperty,
  TemporalInterpolation,
} from '../types/editor';

interface TimelineProps {
  layers: Layer[];
  selectedLayerId: string | null;
  selectedKeyframeId: string | null;
  currentTime: number;
  duration: number;
  fps: number;
  onSelectLayer: (id: string | null) => void;
  onSelectKeyframe: (keyframeId: string | null) => void;
  onSeek: (time: number) => void;
  onUpdateLayerTime: (id: string, start: number, duration: number) => void;
  onSplitLayer: (id: string, time: number) => void;
  onDuplicateLayer: (id: string) => void;
  onDeleteLayer: (id: string) => void;
  onToggleLayerVisibility: (id: string) => void;
  onToggleLayerLock: (id: string) => void;
  onAddKeyframeAtPlayhead: (layerId: string, property: KeyframableProperty) => void;
  onUpdateKeyframeTime: (layerId: string, keyframeId: string, newTime: number) => void;
  onOpenGraphEditor: () => void;
}

export const Timeline: React.FC<TimelineProps> = ({
  layers,
  selectedLayerId,
  selectedKeyframeId,
  currentTime,
  duration,
  fps,
  onSelectLayer,
  onSelectKeyframe,
  onSeek,
  onUpdateLayerTime,
  onSplitLayer,
  onDuplicateLayer,
  onDeleteLayer,
  onToggleLayerVisibility,
  onToggleLayerLock,
  onAddKeyframeAtPlayhead,
  onUpdateKeyframeTime,
  onOpenGraphEditor,
}) => {
  const [zoom, setZoom] = useState(80); // Pixels per second
  const [snapEnabled, setSnapEnabled] = useState(true);
  const timelineTracksRef = useRef<HTMLDivElement | null>(null);

  // Dragging states
  const [isScrubbing, setIsScrubbing] = useState(false);
  const [draggingClip, setDraggingClip] = useState<{
    layerId: string;
    type: 'move' | 'trim-start' | 'trim-end';
    startX: number;
    origStart: number;
    origDuration: number;
  } | null>(null);
  const [draggingKeyframe, setDraggingKeyframe] = useState<{
    layerId: string;
    keyframeId: string;
    startX: number;
    origTime: number;
  } | null>(null);

  const selectedLayer = layers.find((l) => l.id === selectedLayerId);

  // Beat markers at 135 BPM (every 0.444s)
  const bpm = 135;
  const beatInterval = 60 / bpm;
  const beatTimes: number[] = [];
  for (let t = 0; t <= duration; t += beatInterval) {
    beatTimes.push(t);
  }

  // Time conversion
  const timeToPx = (t: number) => t * zoom;
  const pxToTime = (px: number) => Math.max(0, Math.min(duration, px / zoom));

  // Snap time to nearby keyframe or beat marker
  const snapTime = (targetTime: number, thresholdSec: number = 0.08) => {
    if (!snapEnabled) return targetTime;
    // Check beat markers
    for (const b of beatTimes) {
      if (Math.abs(b - targetTime) <= thresholdSec) return b;
    }
    // Check playhead
    if (Math.abs(currentTime - targetTime) <= thresholdSec) return currentTime;
    // Check other layer edges
    for (const l of layers) {
      if (Math.abs(l.start - targetTime) <= thresholdSec) return l.start;
      if (Math.abs(l.start + l.duration - targetTime) <= thresholdSec)
        return l.start + l.duration;
    }
    return targetTime;
  };

  // Playhead scrubber pointer events
  const handleRulerPointerDown = (e: React.PointerEvent) => {
    setIsScrubbing(true);
    (e.target as Element).setPointerCapture(e.pointerId);
    seekFromClientX(e.clientX);
  };

  const seekFromClientX = (clientX: number) => {
    if (!timelineTracksRef.current) return;
    const rect = timelineTracksRef.current.getBoundingClientRect();
    const scrollLeft = timelineTracksRef.current.scrollLeft;
    const clickX = clientX - rect.left + scrollLeft;
    const t = snapTime(pxToTime(clickX));
    onSeek(t);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (isScrubbing) {
      seekFromClientX(e.clientX);
    } else if (draggingClip) {
      const dx = e.clientX - draggingClip.startX;
      const dt = dx / zoom;
      const { layerId, type, origStart, origDuration } = draggingClip;

      if (type === 'move') {
        const newStart = Math.max(0, snapTime(origStart + dt));
        onUpdateLayerTime(layerId, newStart, origDuration);
      } else if (type === 'trim-start') {
        const newStart = Math.min(
          origStart + origDuration - 0.2,
          Math.max(0, origStart + dt)
        );
        const newDur = origDuration - (newStart - origStart);
        onUpdateLayerTime(layerId, newStart, newDur);
      } else if (type === 'trim-end') {
        const newDur = Math.max(0.2, origDuration + dt);
        onUpdateLayerTime(layerId, origStart, newDur);
      }
    } else if (draggingKeyframe) {
      const dx = e.clientX - draggingKeyframe.startX;
      const dt = dx / zoom;
      const newTime = Math.max(0, Math.min(duration, snapTime(draggingKeyframe.origTime + dt)));
      onUpdateKeyframeTime(
        draggingKeyframe.layerId,
        draggingKeyframe.keyframeId,
        newTime
      );
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsScrubbing(false);
    setDraggingClip(null);
    setDraggingKeyframe(null);
    try {
      (e.target as Element).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
  };

  // Group layers into distinct tracks (0, 1, 2, 3...)
  const maxTrack = Math.max(3, ...layers.map((l) => l.trackIndex));
  const tracks = Array.from({ length: maxTrack + 1 }, (_, i) => i);

  const getLayerIcon = (type: Layer['type']) => {
    switch (type) {
      case 'video':
      case 'image':
        return <Video className="w-3.5 h-3.5 text-cyan-400" />;
      case 'text':
        return <Type className="w-3.5 h-3.5 text-violet-400" />;
      case 'shape':
        return <Square className="w-3.5 h-3.5 text-pink-400" />;
      case 'audio':
        return <Music className="w-3.5 h-3.5 text-amber-400" />;
      default:
        return <Layers className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  return (
    <div
      className="h-72 bg-[#0c0e14] border-t border-[#1e2330] flex flex-col select-none text-slate-200"
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      {/* Timeline Action Bar */}
      <div className="flex items-center justify-between px-4 py-1.5 bg-[#12151e] border-b border-[#1c2230] text-xs shrink-0">
        <div className="flex items-center gap-1.5">
          {/* Split Clip Button */}
          <button
            onClick={() => {
              if (selectedLayer) {
                onSplitLayer(selectedLayer.id, currentTime);
              }
            }}
            disabled={!selectedLayer}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#1a1f2c] hover:bg-[#252c3e] border border-[#262e40] text-slate-300 disabled:opacity-40 transition-colors"
            title="Split Clip at Playhead (S or Ctrl+B)"
          >
            <Scissors className="w-3.5 h-3.5 text-violet-400" />
            <span>Split</span>
          </button>

          {/* Add Keyframe diamond at Playhead */}
          <button
            onClick={() => {
              if (selectedLayer) {
                onAddKeyframeAtPlayhead(selectedLayer.id, 'scale.x');
              }
            }}
            disabled={!selectedLayer}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#1a1f2c] hover:bg-[#252c3e] border border-[#262e40] text-slate-300 disabled:opacity-40 transition-colors"
            title="Add Keyframe at Playhead"
          >
            <Diamond className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400/30" />
            <span>Add Keyframe</span>
          </button>

          {/* Graph Editor Trigger */}
          <button
            onClick={onOpenGraphEditor}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#1a1f2c] hover:bg-[#252c3e] border border-[#262e40] text-violet-300 hover:text-white transition-colors"
            title="Open Bezier Graph & Easing Editor"
          >
            <Activity className="w-3.5 h-3.5 text-violet-400" />
            <span>Graph Curve</span>
          </button>

          {/* Duplicate */}
          <button
            onClick={() => {
              if (selectedLayer) onDuplicateLayer(selectedLayer.id);
            }}
            disabled={!selectedLayer}
            className="p-1 rounded bg-[#1a1f2c] hover:bg-[#252c3e] border border-[#262e40] text-slate-400 hover:text-slate-200 disabled:opacity-40 transition-colors"
            title="Duplicate Layer"
          >
            <Copy className="w-3.5 h-3.5" />
          </button>

          {/* Delete */}
          <button
            onClick={() => {
              if (selectedLayer) onDeleteLayer(selectedLayer.id);
            }}
            disabled={!selectedLayer}
            className="p-1 rounded bg-[#1a1f2c] hover:bg-[#252c3e] border border-[#262e40] text-slate-400 hover:text-rose-400 disabled:opacity-40 transition-colors"
            title="Delete Selected Clip (Delete / Backspace)"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          {/* Snapping Magnet */}
          <button
            onClick={() => setSnapEnabled(!snapEnabled)}
            className={`p-1 rounded border transition-colors ${
              snapEnabled
                ? 'bg-cyan-950/60 border-cyan-500/50 text-cyan-400'
                : 'bg-[#1a1f2c] border-[#262e40] text-slate-400'
            }`}
            title="Magnetic Beat & Edge Snapping"
          >
            <Magnet className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Right: Timeline Zoom */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setZoom(Math.max(30, zoom - 15))}
            className="p-1 text-slate-400 hover:text-white"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <input
            type="range"
            min="30"
            max="180"
            value={zoom}
            onChange={(e) => setZoom(Number(e.target.value))}
            className="w-20 accent-violet-500 h-1 bg-[#232938] rounded cursor-pointer"
          />
          <button
            onClick={() => setZoom(Math.min(180, zoom + 15))}
            className="p-1 text-slate-400 hover:text-white"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <span className="font-mono text-[11px] text-slate-400 w-10 text-right">
            {zoom}px/s
          </span>
        </div>
      </div>

      {/* Main Multi-Track Timeline Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left: Track Headers Sidebar (180px) */}
        <div className="w-48 bg-[#0e1118] border-r border-[#1e2330] flex flex-col shrink-0 select-none z-10">
          {/* Top corner blank matching ruler height */}
          <div className="h-6 border-b border-[#1e2330] px-3 flex items-center justify-between text-[11px] text-slate-400 font-medium">
            <span>Tracks</span>
            <span className="text-[10px] text-violet-400 font-mono">135 BPM</span>
          </div>

          {/* Track Rows Header */}
          <div className="flex-1 overflow-y-auto">
            {tracks.map((trackIdx) => {
              const trackLayers = layers.filter((l) => l.trackIndex === trackIdx);
              const isSelected = trackLayers.some((l) => l.id === selectedLayerId);
              const firstLayer = trackLayers[0];

              return (
                <div
                  key={trackIdx}
                  className={`h-11 px-3 border-b border-[#191e2b] flex items-center justify-between transition-colors ${
                    isSelected ? 'bg-violet-950/20' : 'hover:bg-[#131620]'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    {firstLayer ? (
                      getLayerIcon(firstLayer.type)
                    ) : (
                      <Layers className="w-3.5 h-3.5 text-slate-500" />
                    )}
                    <span className="text-xs font-medium text-slate-300 truncate">
                      {firstLayer ? firstLayer.name : `Track ${trackIdx + 1}`}
                    </span>
                  </div>

                  {firstLayer && (
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => onToggleLayerVisibility(firstLayer.id)}
                        className={`p-0.5 rounded hover:text-white ${
                          firstLayer.visible ? 'text-slate-400' : 'text-slate-600'
                        }`}
                      >
                        {firstLayer.visible ? (
                          <Eye className="w-3 h-3" />
                        ) : (
                          <EyeOff className="w-3 h-3" />
                        )}
                      </button>
                      <button
                        onClick={() => onToggleLayerLock(firstLayer.id)}
                        className={`p-0.5 rounded hover:text-white ${
                          firstLayer.locked ? 'text-amber-400' : 'text-slate-600'
                        }`}
                      >
                        {firstLayer.locked ? (
                          <Lock className="w-3 h-3" />
                        ) : (
                          <Unlock className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Scrollable Timeline Tracks & Ruler */}
        <div
          ref={timelineTracksRef}
          className="flex-1 overflow-x-auto overflow-y-auto relative bg-[#090b10] timeline-grid"
        >
          {/* Tracks Content Container */}
          <div
            className="relative h-full"
            style={{ width: `${Math.max(1200, duration * zoom + 200)}px` }}
          >
            {/* Top Timecode Ruler */}
            <div
              className="h-6 border-b border-[#1e2330] relative cursor-pointer bg-[#0e1118]"
              onPointerDown={handleRulerPointerDown}
            >
              {/* Seconds marks */}
              {Array.from({ length: Math.ceil(duration) + 1 }, (_, sec) => (
                <div
                  key={sec}
                  className="absolute top-0 bottom-0 border-l border-slate-700/60 pl-1 text-[10px] font-mono text-slate-400 select-none pointer-events-none"
                  style={{ left: `${sec * zoom}px` }}
                >
                  {sec}s
                </div>
              ))}

              {/* Glowing Beat Markers (Amber dots at 135 BPM) */}
              {beatTimes.map((bt, idx) => (
                <div
                  key={idx}
                  className="absolute bottom-0 w-1.5 h-1.5 -translate-x-1/2 rounded-full bg-amber-400/80 shadow-xs pointer-events-none"
                  style={{ left: `${bt * zoom}px` }}
                  title={`Beat ${idx + 1}`}
                />
              ))}
            </div>

            {/* Track Lanes */}
            <div className="relative">
              {tracks.map((trackIdx) => {
                const trackLayers = layers.filter(
                  (l) => l.trackIndex === trackIdx
                );

                return (
                  <div
                    key={trackIdx}
                    className="h-11 border-b border-[#171b26] relative"
                  >
                    {/* Render clips on this track */}
                    {trackLayers.map((layer) => {
                      const isSelected = layer.id === selectedLayerId;
                      const leftPx = timeToPx(layer.start);
                      const widthPx = timeToPx(layer.duration);

                      return (
                        <div
                          key={layer.id}
                          className={`absolute top-1 bottom-1 rounded-md border text-xs overflow-visible group cursor-grab active:cursor-grabbing transition-shadow ${
                            isSelected
                              ? 'bg-violet-900/60 border-violet-400 shadow-md shadow-violet-500/20'
                              : 'bg-[#181d2a] border-[#293246] hover:border-slate-500'
                          }`}
                          style={{
                            left: `${leftPx}px`,
                            width: `${widthPx}px`,
                          }}
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectLayer(layer.id);
                          }}
                          onPointerDown={(e) => {
                            e.stopPropagation();
                            onSelectLayer(layer.id);
                            setDraggingClip({
                              layerId: layer.id,
                              type: 'move',
                              startX: e.clientX,
                              origStart: layer.start,
                              origDuration: layer.duration,
                            });
                            (e.target as Element).setPointerCapture(e.pointerId);
                          }}
                        >
                          {/* Clip Header Label */}
                          <div className="px-2 py-0.5 flex items-center justify-between text-[11px] font-medium text-slate-200 truncate pointer-events-none">
                            <span className="truncate">{layer.name}</span>
                            {layer.speedRamp?.enabled && (
                              <span className="text-[9px] px-1 bg-amber-500/20 text-amber-300 rounded font-mono">
                                RAMP
                              </span>
                            )}
                          </div>

                          {/* Left Trim Handle */}
                          <div
                            className="absolute left-0 top-0 bottom-0 w-2.5 bg-violet-500/40 hover:bg-violet-400 rounded-l cursor-ew-resize opacity-0 group-hover:opacity-100 transition-opacity"
                            onPointerDown={(e) => {
                              e.stopPropagation();
                              setDraggingClip({
                                layerId: layer.id,
                                type: 'trim-start',
                                startX: e.clientX,
                                origStart: layer.start,
                                origDuration: layer.duration,
                              });
                              (e.target as Element).setPointerCapture(e.pointerId);
                            }}
                          />

                          {/* Right Trim Handle */}
                          <div
                            className="absolute right-0 top-0 bottom-0 w-2.5 bg-violet-500/40 hover:bg-violet-400 rounded-r cursor-ew-resize opacity-0 group-hover:opacity-100 transition-opacity"
                            onPointerDown={(e) => {
                              e.stopPropagation();
                              setDraggingClip({
                                layerId: layer.id,
                                type: 'trim-end',
                                startX: e.clientX,
                                origStart: layer.start,
                                origDuration: layer.duration,
                              });
                              (e.target as Element).setPointerCapture(e.pointerId);
                            }}
                          />

                          {/* Keyframe Diamonds on Clip Bar */}
                          {layer.keyframes.map((kf) => {
                            const kfOffsetSec = kf.time - layer.start;
                            if (kfOffsetSec < 0 || kfOffsetSec > layer.duration) {
                              return null;
                            }
                            const kfPx = timeToPx(kfOffsetSec);
                            const isKfSelected = kf.id === selectedKeyframeId;

                            return (
                              <div
                                key={kf.id}
                                className={`absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3.5 h-3.5 rotate-45 border cursor-pointer hover:scale-125 transition-transform z-10 ${
                                  isKfSelected
                                    ? 'bg-amber-400 border-white shadow-md'
                                    : kf.interpolation === 'hold'
                                    ? 'bg-rose-500 border-rose-300'
                                    : 'bg-cyan-400 border-slate-900 shadow-xs'
                                }`}
                                style={{ left: `${kfPx}px` }}
                                title={`${kf.property}: ${kf.value} (${kf.interpolation})`}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onSelectLayer(layer.id);
                                  onSelectKeyframe(kf.id);
                                }}
                                onPointerDown={(e) => {
                                  e.stopPropagation();
                                  onSelectLayer(layer.id);
                                  onSelectKeyframe(kf.id);
                                  setDraggingKeyframe({
                                    layerId: layer.id,
                                    keyframeId: kf.id,
                                    startX: e.clientX,
                                    origTime: kf.time,
                                  });
                                  (e.target as Element).setPointerCapture(e.pointerId);
                                }}
                              />
                            );
                          })}
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>

            {/* Glowing Playhead Line */}
            <div
              className="absolute top-0 bottom-0 w-[2px] bg-red-500 shadow-md shadow-red-500/50 pointer-events-none z-20"
              style={{ left: `${timeToPx(currentTime)}px` }}
            >
              {/* Red playhead scrubber head */}
              <div className="w-3.5 h-3.5 bg-red-500 rotate-45 -translate-x-1.5 -translate-y-1.5 shadow-md" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
