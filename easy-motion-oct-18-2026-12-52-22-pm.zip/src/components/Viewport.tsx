import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Maximize2,
  Grid,
  Sparkles,
  Split,
  Eye,
  ZoomIn,
  Move,
  RotateCw,
} from 'lucide-react';
import {
  Layer,
  ProjectSettings,
  TopazSettings,
  Keyframe,
  KeyframableProperty,
} from '../types/editor';
import { interpolateKeyframes } from '../utils/bezier';
import { applyTopazEnhancement } from '../utils/topazShader';

interface ViewportProps {
  project: ProjectSettings;
  layers: Layer[];
  selectedLayerId: string | null;
  currentTime: number;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onSeek: (time: number) => void;
  topazSettings: TopazSettings;
  onUpdateLayerTransform: (
    layerId: string,
    transform: {
      position: { x: number; y: number };
      scale: { x: number; y: number };
      rotation: number;
      anchorPoint: { x: number; y: number };
    }
  ) => void;
  onUpdateTopazSettings: (newSettings: Partial<TopazSettings>) => void;
}

export const Viewport: React.FC<ViewportProps> = ({
  project,
  layers,
  selectedLayerId,
  currentTime,
  isPlaying,
  onTogglePlay,
  onSeek,
  topazSettings,
  onUpdateLayerTransform,
  onUpdateTopazSettings,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const offscreenCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const imageCacheRef = useRef<Map<string, HTMLImageElement>>(new Map());

  // Gizmo & Viewport state
  const [showGrid, setShowGrid] = useState(false);
  const [showSafeZone, setShowSafeZone] = useState(false);
  const [zoomLevel, setZoomLevel] = useState<'fit' | '50' | '100'>('fit');
  const [isDraggingGizmo, setIsDraggingGizmo] = useState<
    'move' | 'scale-tl' | 'scale-br' | 'rotate' | null
  >(null);
  const dragStartRef = useRef<{
    x: number;
    y: number;
    origPos: { x: number; y: number };
    origScale: { x: number; y: number };
    origRot: number;
  }>({
    x: 0,
    y: 0,
    origPos: { x: 0, y: 0 },
    origScale: { x: 1, y: 1 },
    origRot: 0,
  });

  // Calculate project dimensions based on aspect ratio
  const canvasWidth = project.aspectRatio === '9:16' ? 1080 : 1920;
  const canvasHeight = project.aspectRatio === '9:16' ? 1920 : project.aspectRatio === '1:1' ? 1080 : 1080;

  // Preload images into cache
  useEffect(() => {
    layers.forEach((layer) => {
      if (layer.sourceUrl && !imageCacheRef.current.has(layer.sourceUrl)) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = layer.sourceUrl;
        img.onload = () => {
          imageCacheRef.current.set(layer.sourceUrl!, img);
        };
      }
    });
  }, [layers]);

  // Interpolate property at currentTime for a given layer
  const getInterpolatedValue = useCallback(
    (layer: Layer, prop: KeyframableProperty, fallback: number): number => {
      const kfs = layer.keyframes.filter((k) => k.property === prop);
      if (kfs.length === 0) return fallback;
      if (kfs.length === 1) return kfs[0].value;

      kfs.sort((a, b) => a.time - b.time);

      if (currentTime <= kfs[0].time) return kfs[0].value;
      if (currentTime >= kfs[kfs.length - 1].time)
        return kfs[kfs.length - 1].value;

      for (let i = 0; i < kfs.length - 1; i++) {
        const k1 = kfs[i];
        const k2 = kfs[i + 1];
        if (currentTime >= k1.time && currentTime <= k2.time) {
          return interpolateKeyframes(
            currentTime,
            k1.time,
            k1.value,
            k2.time,
            k2.value,
            k2.interpolation || 'bezier',
            k2.curve,
            k2.bezierHandle
          );
        }
      }
      return fallback;
    },
    [currentTime]
  );

  // Compute compound transform including parent layer inheritance (After Effects parenting)
  const computeLayerTransform = useCallback(
    (layer: Layer) => {
      let posX = getInterpolatedValue(layer, 'position.x', layer.transform.position.x);
      let posY = getInterpolatedValue(layer, 'position.y', layer.transform.position.y);
      let scaleX = getInterpolatedValue(layer, 'scale.x', layer.transform.scale.x);
      let scaleY = getInterpolatedValue(layer, 'scale.y', layer.transform.scale.y);
      let rot = getInterpolatedValue(layer, 'rotation', layer.transform.rotation);
      const opacity = getInterpolatedValue(layer, 'opacity', layer.opacity);

      // Check camera shake effect
      const shakeEff = layer.effects.find(
        (e) => e.type === 'cameraShake' && e.enabled
      );
      if (shakeEff) {
        const freq = (shakeEff.params.frequency as number) || 5;
        const amp = (shakeEff.params.amplitude as number) || 5;
        posX += Math.sin(currentTime * freq * 6.28) * amp;
        posY += Math.cos(currentTime * freq * 4.15) * amp;
        rot += Math.sin(currentTime * freq * 3.14) * (amp * 0.2);
      }

      // If parented to another layer, compound transforms
      if (layer.parentId) {
        const parent = layers.find((l) => l.id === layer.parentId);
        if (parent) {
          const parentTrans = computeLayerTransform(parent);
          posX += parentTrans.posX;
          posY += parentTrans.posY;
          scaleX *= parentTrans.scaleX;
          scaleY *= parentTrans.scaleY;
          rot += parentTrans.rot;
        }
      }

      return { posX, posY, scaleX, scaleY, rot, opacity };
    },
    [getInterpolatedValue, layers, currentTime]
  );

  // Main rendering loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    if (!offscreenCanvasRef.current) {
      offscreenCanvasRef.current = document.createElement('canvas');
    }
    const offCanvas = offscreenCanvasRef.current;
    offCanvas.width = canvasWidth;
    offCanvas.height = canvasHeight;
    canvas.width = canvasWidth;
    canvas.height = canvasHeight;

    const offCtx = offCanvas.getContext('2d');
    if (!offCtx) return;

    // Clear background
    offCtx.fillStyle = '#07080b';
    offCtx.fillRect(0, 0, canvasWidth, canvasHeight);

    // Sort visible layers by trackIndex ascending (track 0 is background, higher tracks sit on top)
    const sortedLayers = [...layers].sort((a, b) => a.trackIndex - b.trackIndex);

    for (const layer of sortedLayers) {
      if (!layer.visible) continue;
      // Check if current playhead is within clip's lifespan
      if (currentTime < layer.start || currentTime > layer.start + layer.duration) {
        continue;
      }

      const { posX, posY, scaleX, scaleY, rot, opacity } =
        computeLayerTransform(layer);

      offCtx.save();
      // Apply opacity
      offCtx.globalAlpha = Math.max(0, Math.min(1, opacity / 100));

      // Apply blend mode
      if (layer.blendMode === 'screen') offCtx.globalCompositeOperation = 'screen';
      else if (layer.blendMode === 'multiply') offCtx.globalCompositeOperation = 'multiply';
      else if (layer.blendMode === 'add') offCtx.globalCompositeOperation = 'lighter';
      else if (layer.blendMode === 'color-dodge') offCtx.globalCompositeOperation = 'color-dodge';
      else if (layer.blendMode === 'overlay') offCtx.globalCompositeOperation = 'overlay';
      else if (layer.blendMode === 'difference') offCtx.globalCompositeOperation = 'difference';
      else offCtx.globalCompositeOperation = 'source-over';

      // Transform matrix centered on canvas
      const centerX = canvasWidth / 2 + posX;
      const centerY = canvasHeight / 2 + posY;

      offCtx.translate(centerX, centerY);
      offCtx.rotate((rot * Math.PI) / 180);
      offCtx.scale(scaleX, scaleY);

      // Check Chromatic Aberration effect
      const caEff = layer.effects.find((e) => e.type === 'chromaticAberration' && e.enabled);

      // Render layer content based on type
      if (layer.type === 'image' && layer.sourceUrl) {
        const img = imageCacheRef.current.get(layer.sourceUrl);
        if (img && img.complete) {
          const drawW = canvasWidth;
          const drawH = canvasHeight;
          const drawX = -drawW / 2;
          const drawY = -drawH / 2;

          // If chromatic aberration is enabled, simulate RGB split pass
          if (caEff) {
            const offset = (caEff.params.offset as number) || 4;
            // Red channel offset
            offCtx.shadowColor = 'rgba(255, 0, 70, 0.4)';
            offCtx.shadowOffsetX = -offset;
            offCtx.drawImage(img, drawX, drawY, drawW, drawH);
            // Cyan channel offset
            offCtx.shadowColor = 'rgba(0, 240, 255, 0.4)';
            offCtx.shadowOffsetX = offset;
            offCtx.drawImage(img, drawX, drawY, drawW, drawH);
            offCtx.shadowOffsetX = 0;
            offCtx.shadowColor = 'transparent';
          }

          offCtx.drawImage(img, drawX, drawY, drawW, drawH);
        } else {
          // Fallback placeholder while image caches
          offCtx.fillStyle = '#161a24';
          offCtx.fillRect(-canvasWidth / 2, -canvasHeight / 2, canvasWidth, canvasHeight);
        }
      } else if (layer.type === 'text' && layer.text) {
        offCtx.font = `700 ${layer.fontSize || 60}px ${layer.fontFamily || 'Plus Jakarta Sans'}, sans-serif`;
        offCtx.textAlign = 'center';
        offCtx.textBaseline = 'middle';

        // Check neon glow effect
        const glowEff = layer.effects.find((e) => e.type === 'deepGlow' && e.enabled);
        if (glowEff) {
          offCtx.shadowColor = layer.strokeColor || '#8b5cf6';
          offCtx.shadowBlur = (glowEff.params.radius as number) || 20;
        }

        if (layer.strokeWidth && layer.strokeWidth > 0) {
          offCtx.strokeStyle = layer.strokeColor || '#8b5cf6';
          offCtx.lineWidth = layer.strokeWidth;
          offCtx.strokeText(layer.text, 0, 0);
        }

        offCtx.fillStyle = layer.fillColor || '#ffffff';
        offCtx.fillText(layer.text, 0, 0);
      } else if (layer.type === 'shape') {
        offCtx.fillStyle = layer.fillColor || '#8b5cf6';
        if (layer.shapeType === 'circle') {
          offCtx.beginPath();
          offCtx.arc(0, 0, 120, 0, Math.PI * 2);
          offCtx.fill();
        } else {
          offCtx.fillRect(-100, -100, 200, 200);
        }
      }

      offCtx.restore();
    }

    // Now apply Topaz Super-Resolution & Neural Enhancement pass to canvas
    applyTopazEnhancement(offCanvas, canvas, topazSettings, currentTime);

    // Draw Grid or Safe Zone overlays if enabled
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (showGrid) {
      ctx.save();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
      ctx.lineWidth = 1;
      // Rule of thirds lines
      ctx.beginPath();
      ctx.moveTo(canvasWidth / 3, 0);
      ctx.lineTo(canvasWidth / 3, canvasHeight);
      ctx.moveTo((canvasWidth * 2) / 3, 0);
      ctx.lineTo((canvasWidth * 2) / 3, canvasHeight);
      ctx.moveTo(0, canvasHeight / 3);
      ctx.lineTo(canvasWidth, canvasHeight / 3);
      ctx.moveTo(0, (canvasHeight * 2) / 3);
      ctx.lineTo(canvasWidth, (canvasHeight * 2) / 3);
      ctx.stroke();
      ctx.restore();
    }

    if (showSafeZone) {
      ctx.save();
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.4)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 6]);
      // 90% Action Safe box
      const marginX = canvasWidth * 0.05;
      const marginY = canvasHeight * 0.05;
      ctx.strokeRect(marginX, marginY, canvasWidth - marginX * 2, canvasHeight - marginY * 2);
      ctx.restore();
    }
  }, [
    layers,
    currentTime,
    topazSettings,
    canvasWidth,
    canvasHeight,
    showGrid,
    showSafeZone,
    computeLayerTransform,
  ]);

  // Selected layer reference for bounding box
  const selectedLayer = layers.find((l) => l.id === selectedLayerId);

  // Timecode formatting: HH:MM:SS:FF
  const formatTimecode = (sec: number, fps: number = 30) => {
    const totalFrames = Math.floor(sec * fps);
    const frames = totalFrames % fps;
    const totalSeconds = Math.floor(sec);
    const s = totalSeconds % 60;
    const m = Math.floor(totalSeconds / 60) % 60;
    const h = Math.floor(totalSeconds / 3600);
    return `${h.toString().padStart(2, '0')}:${m
      .toString()
      .padStart(2, '0')}:${s.toString().padStart(2, '0')}:${frames
      .toString()
      .padStart(2, '0')}`;
  };

  // Interactive Gizmo dragging handlers
  const handlePointerDownGizmo = (
    mode: 'move' | 'scale-tl' | 'scale-br' | 'rotate',
    e: React.PointerEvent
  ) => {
    if (!selectedLayer) return;
    e.stopPropagation();
    setIsDraggingGizmo(mode);
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      origPos: { ...selectedLayer.transform.position },
      origScale: { ...selectedLayer.transform.scale },
      origRot: selectedLayer.transform.rotation,
    };
    (e.target as Element).setPointerCapture(e.pointerId);
  };

  const handlePointerMoveGizmo = (e: React.PointerEvent) => {
    if (!isDraggingGizmo || !selectedLayer) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;

    if (isDraggingGizmo === 'move') {
      onUpdateLayerTransform(selectedLayer.id, {
        ...selectedLayer.transform,
        position: {
          x: Math.round(dragStartRef.current.origPos.x + dx),
          y: Math.round(dragStartRef.current.origPos.y + dy),
        },
      });
    } else if (isDraggingGizmo === 'scale-br') {
      const scaleDelta = dx * 0.005;
      const newScale = Math.max(0.1, dragStartRef.current.origScale.x + scaleDelta);
      onUpdateLayerTransform(selectedLayer.id, {
        ...selectedLayer.transform,
        scale: { x: newScale, y: newScale },
      });
    } else if (isDraggingGizmo === 'rotate') {
      const rotDelta = dx * 0.5;
      onUpdateLayerTransform(selectedLayer.id, {
        ...selectedLayer.transform,
        rotation: Math.round(dragStartRef.current.origRot + rotDelta),
      });
    }
  };

  const handlePointerUpGizmo = (e: React.PointerEvent) => {
    setIsDraggingGizmo(null);
    try {
      (e.target as Element).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
  };

  return (
    <div
      ref={containerRef}
      className="flex-1 flex flex-col bg-[#08090d] relative overflow-hidden select-none min-h-0"
    >
      {/* Top Floating Viewport Control Toolbar */}
      <div className="flex items-center justify-between px-4 py-2 bg-[#0e1015]/90 border-b border-[#1b202c] z-10 shrink-0 text-xs">
        <div className="flex items-center gap-3">
          {/* Resolution Badge */}
          <div className="flex items-center gap-1.5 font-mono text-slate-300">
            <span className="text-violet-400 font-semibold">
              {project.aspectRatio === '9:16' ? '1080×1920' : '3840×2160'}
            </span>
            <span className="text-slate-500">·</span>
            <span>{project.fps} FPS</span>
            {topazSettings.enabled && (
              <>
                <span className="text-slate-500">·</span>
                <span className="text-cyan-400 font-semibold flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  Topaz 4K Neural
                </span>
              </>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Grid and Safe Margins */}
          <button
            onClick={() => setShowGrid(!showGrid)}
            className={`p-1.5 rounded transition-colors ${
              showGrid
                ? 'bg-violet-600/30 text-violet-300'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#181d29]'
            }`}
            title="Toggle Rule of Thirds Grid"
          >
            <Grid className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setShowSafeZone(!showSafeZone)}
            className={`p-1.5 rounded transition-colors ${
              showSafeZone
                ? 'bg-cyan-600/30 text-cyan-300'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#181d29]'
            }`}
            title="Toggle Title Safe Margins"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>

          {/* Curtain Split Toggle */}
          <button
            onClick={() =>
              onUpdateTopazSettings({ splitView: !topazSettings.splitView })
            }
            className={`flex items-center gap-1 px-2 py-1 rounded transition-colors font-medium ${
              topazSettings.splitView
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Side-by-side Topaz curtain slider"
          >
            <Split className="w-3 h-3" />
            <span>Curtain</span>
          </button>
        </div>
      </div>

      {/* Main Preview Screen Area */}
      <div className="flex-1 relative flex items-center justify-center p-4 min-h-0 bg-[#07080b]">
        <div
          className="relative max-h-full max-w-full flex items-center justify-center shadow-2xl rounded-md overflow-hidden border border-[#1a1f2b]"
          style={{
            aspectRatio:
              project.aspectRatio === '9:16'
                ? '9/16'
                : project.aspectRatio === '1:1'
                ? '1/1'
                : '16/9',
            maxHeight: 'calc(100% - 10px)',
          }}
        >
          {/* Canvas Render Element */}
          <canvas
            ref={canvasRef}
            className="w-full h-full object-contain block pointer-events-none"
          />

          {/* Direct-Manipulation Transform Gizmo Overlay */}
          {selectedLayer && selectedLayer.visible && (
            <div
              className="absolute inset-0 pointer-events-none flex items-center justify-center"
              style={{
                transform: `translate(${selectedLayer.transform.position.x}px, ${selectedLayer.transform.position.y}px) rotate(${selectedLayer.transform.rotation}deg)`,
              }}
            >
              {/* Bounding Box Border */}
              <div
                className="relative border-2 border-dashed border-violet-400/80 pointer-events-auto cursor-move flex items-center justify-center"
                style={{
                  width: `${Math.min(360, Math.max(120, 200 * selectedLayer.transform.scale.x))}px`,
                  height: `${Math.min(260, Math.max(80, 140 * selectedLayer.transform.scale.y))}px`,
                }}
                onPointerDown={(e) => handlePointerDownGizmo('move', e)}
                onPointerMove={handlePointerMoveGizmo}
                onPointerUp={handlePointerUpGizmo}
              >
                {/* Center Anchor Point Crosshair */}
                <div className="w-2.5 h-2.5 rounded-full border border-violet-300 bg-violet-600/80 shadow-xs pointer-events-none" />

                {/* Top Rotation Handle */}
                <div
                  className="absolute -top-7 w-5 h-5 rounded-full bg-violet-500 hover:bg-violet-400 text-white flex items-center justify-center cursor-grab active:cursor-grabbing shadow-md pointer-events-auto"
                  title="Drag to Rotate"
                  onPointerDown={(e) => handlePointerDownGizmo('rotate', e)}
                  onPointerMove={handlePointerMoveGizmo}
                  onPointerUp={handlePointerUpGizmo}
                >
                  <RotateCw className="w-3 h-3" />
                </div>

                {/* Corner Scale Handle Bottom-Right */}
                <div
                  className="absolute -bottom-1.5 -right-1.5 w-3.5 h-3.5 rounded bg-cyan-400 hover:scale-125 border border-white cursor-se-resize pointer-events-auto transition-transform"
                  title="Drag to Scale"
                  onPointerDown={(e) => handlePointerDownGizmo('scale-br', e)}
                  onPointerMove={handlePointerMoveGizmo}
                  onPointerUp={handlePointerUpGizmo}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Transport Bar (Play/Pause, Step Frames, Timecode) */}
      <div className="flex items-center justify-between px-5 py-2.5 bg-[#0e1015] border-t border-[#1b202c] z-10 shrink-0 select-none">
        {/* Left: Timecode */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-violet-400 font-bold bg-[#141822] px-2 py-1 rounded border border-[#232938]">
            {formatTimecode(currentTime, project.fps)}
          </span>
          <span className="text-slate-500">/</span>
          <span className="text-slate-400">
            {formatTimecode(project.duration, project.fps)}
          </span>
        </div>

        {/* Center: Play / Pause & Step Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onSeek(Math.max(0, currentTime - 1 / project.fps))}
            className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-[#181d29] transition-colors"
            title="Step Back 1 Frame (J)"
          >
            <SkipBack className="w-4 h-4" />
          </button>

          <button
            onClick={onTogglePlay}
            className={`p-2.5 rounded-full text-white shadow-lg transition-transform active:scale-95 ${
              isPlaying
                ? 'bg-amber-500 hover:bg-amber-400'
                : 'bg-violet-600 hover:bg-violet-500'
            }`}
            title="Play / Pause (Space)"
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 fill-current" />
            ) : (
              <Play className="w-4 h-4 fill-current translate-x-0.5" />
            )}
          </button>

          <button
            onClick={() =>
              onSeek(Math.min(project.duration, currentTime + 1 / project.fps))
            }
            className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-[#181d29] transition-colors"
            title="Step Forward 1 Frame (L)"
          >
            <SkipForward className="w-4 h-4" />
          </button>
        </div>

        {/* Right: Quick Zoom & Audio indicator */}
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className="font-mono">Fit View</span>
        </div>
      </div>
    </div>
  );
};
