import React, { useState, useRef, useEffect } from 'react';
import {
  Activity,
  Play,
  RotateCcw,
  Check,
  Zap,
  TrendingUp,
  Sliders,
  X,
} from 'lucide-react';
import { BezierCurveType, BezierHandle, Keyframe, Layer } from '../types/editor';
import { CURVE_PRESETS, solveCubicBezier } from '../utils/bezier';

interface GraphEditorProps {
  selectedLayer: Layer | null;
  selectedKeyframe: Keyframe | null;
  onUpdateKeyframeCurve: (
    layerId: string,
    keyframeId: string,
    curve: BezierCurveType,
    handle: BezierHandle
  ) => void;
  onClose?: () => void;
}

export const GraphEditor: React.FC<GraphEditorProps> = ({
  selectedLayer,
  selectedKeyframe,
  onUpdateKeyframeCurve,
  onClose,
}) => {
  // Current bezier handles
  const initialHandle =
    selectedKeyframe?.bezierHandle ||
    (selectedKeyframe?.curve ? CURVE_PRESETS[selectedKeyframe.curve] : null) ||
    CURVE_PRESETS.easeInOut;

  const [handle, setHandle] = useState<BezierHandle>(initialHandle);
  const [activeCurveType, setActiveCurveType] = useState<BezierCurveType>(
    selectedKeyframe?.curve || 'easeInOut'
  );
  const [activeTab, setActiveTab] = useState<'value' | 'speed'>('value');
  const [previewProgress, setPreviewProgress] = useState(0);
  const [isPlayingPreview, setIsPlayingPreview] = useState(true);

  const svgRef = useRef<SVGSVGElement | null>(null);
  const [draggingHandle, setDraggingHandle] = useState<'h1' | 'h2' | null>(null);

  // Update when selected keyframe changes
  useEffect(() => {
    if (selectedKeyframe) {
      const h =
        selectedKeyframe.bezierHandle ||
        CURVE_PRESETS[selectedKeyframe.curve] ||
        CURVE_PRESETS.easeInOut;
      setHandle(h);
      setActiveCurveType(selectedKeyframe.curve);
    }
  }, [selectedKeyframe]);

  // Preview animation loop to feel the easing
  useEffect(() => {
    let animId: number;
    let startTime: number | null = null;
    const duration = 1200; // 1.2s loop

    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const elapsed = (timestamp - startTime) % duration;
      const t = elapsed / duration;
      const eased = solveCubicBezier(handle.x1, handle.y1, handle.x2, handle.y2, t);
      setPreviewProgress(eased);
      if (isPlayingPreview) {
        animId = requestAnimationFrame(step);
      }
    };

    if (isPlayingPreview) {
      animId = requestAnimationFrame(step);
    }
    return () => cancelAnimationFrame(animId);
  }, [handle, isPlayingPreview]);

  // SVG box dimensions
  const padX = 36;
  const padY = 36;
  const graphW = 248;
  const graphH = 168;

  const toSvgX = (x: number) => padX + x * graphW;
  const toSvgY = (y: number) => padY + (1 - y) * graphH;

  const fromSvgX = (svgX: number) =>
    Math.max(0, Math.min(1, (svgX - padX) / graphW));
  const fromSvgY = (svgY: number) =>
    Math.max(-0.4, Math.min(1.4, 1 - (svgY - padY) / graphH));

  const handlePointerDown = (which: 'h1' | 'h2', e: React.PointerEvent) => {
    e.preventDefault();
    setDraggingHandle(which);
    (e.target as Element).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!draggingHandle || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const svgX = e.clientX - rect.left;
    const svgY = e.clientY - rect.top;

    const normX = Math.round(fromSvgX(svgX) * 100) / 100;
    const normY = Math.round(fromSvgY(svgY) * 100) / 100;

    let updated: BezierHandle;
    if (draggingHandle === 'h1') {
      updated = { ...handle, x1: normX, y1: normY };
    } else {
      updated = { ...handle, x2: normX, y2: normY };
    }

    setHandle(updated);
    setActiveCurveType('custom');

    if (selectedLayer && selectedKeyframe) {
      onUpdateKeyframeCurve(selectedLayer.id, selectedKeyframe.id, 'custom', updated);
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setDraggingHandle(null);
    try {
      (e.target as Element).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
  };

  const applyPreset = (presetName: BezierCurveType) => {
    const preset = CURVE_PRESETS[presetName];
    setHandle(preset);
    setActiveCurveType(presetName);
    if (selectedLayer && selectedKeyframe) {
      onUpdateKeyframeCurve(selectedLayer.id, selectedKeyframe.id, presetName, preset);
    }
  };

  // Generate SVG curve path
  const p0 = { x: toSvgX(0), y: toSvgY(0) };
  const p1 = { x: toSvgX(handle.x1), y: toSvgY(handle.y1) };
  const p2 = { x: toSvgX(handle.x2), y: toSvgY(handle.y2) };
  const p3 = { x: toSvgX(1), y: toSvgY(1) };

  const curvePath = `M ${p0.x} ${p0.y} C ${p1.x} ${p1.y}, ${p2.x} ${p2.y}, ${p3.x} ${p3.y}`;

  // Speed Graph derivative points
  const speedPoints: string[] = [];
  const steps = 30;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const dt = 0.02;
    const yA = solveCubicBezier(handle.x1, handle.y1, handle.x2, handle.y2, Math.max(0, t - dt));
    const yB = solveCubicBezier(handle.x1, handle.y1, handle.x2, handle.y2, Math.min(1, t + dt));
    const speed = Math.max(0, (yB - yA) / (2 * dt));
    const sx = toSvgX(t);
    const sy = toSvgY(speed * 0.4);
    speedPoints.push(`${i === 0 ? 'M' : 'L'} ${sx} ${sy}`);
  }
  const speedPath = speedPoints.join(' ');

  return (
    <div className="bg-[#11141c] border border-[#232938] rounded-2xl p-4 shadow-2xl w-full max-w-xl select-none text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-[#232938]">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-yellow-400" />
          <h2 className="text-sm font-bold tracking-tight text-white">
            Easy Motion Curve Editor
          </h2>
          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-yellow-400/20 text-yellow-300 border border-yellow-400/30">
            Bezier Engine
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Value vs Speed graph switch */}
          <div className="flex items-center bg-[#171b26] p-0.5 rounded-lg border border-[#283042] text-xs">
            <button
              onClick={() => setActiveTab('value')}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                activeTab === 'value'
                  ? 'bg-yellow-400 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Value Curve
            </button>
            <button
              onClick={() => setActiveTab('speed')}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                activeTab === 'speed'
                  ? 'bg-yellow-400 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Speed Velocity
            </button>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-white rounded-md hover:bg-[#1a1f2c]"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mt-3">
        {/* Left: Interactive Bezier Canvas (7 cols) */}
        <div className="md:col-span-7 flex flex-col items-center">
          <div className="relative w-full bg-[#0a0c10] border border-[#1f2533] rounded-xl p-2 flex items-center justify-center">
            <svg
              ref={svgRef}
              viewBox="0 0 320 240"
              className="w-full max-w-[320px] h-[220px] touch-none cursor-crosshair overflow-visible"
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
            >
              <defs>
                <linearGradient id="curveGradientEM" x1="0%" y1="100%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#facc15" />
                  <stop offset="100%" stopColor="#06b6d4" />
                </linearGradient>
                <linearGradient id="speedGradientEM" x1="0%" y1="100%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#f59e0b" />
                  <stop offset="100%" stopColor="#ef4444" />
                </linearGradient>
              </defs>

              {/* Baseline and Topline */}
              <line
                x1={padX}
                y1={toSvgY(0)}
                x2={padX + graphW}
                y2={toSvgY(0)}
                stroke="#1f2533"
                strokeWidth="1.5"
                strokeDasharray="3 3"
              />
              <line
                x1={padX}
                y1={toSvgY(1)}
                x2={padX + graphW}
                y2={toSvgY(1)}
                stroke="#1f2533"
                strokeWidth="1.5"
                strokeDasharray="3 3"
              />

              {/* Tangent arms */}
              <line
                x1={p0.x}
                y1={p0.y}
                x2={p1.x}
                y2={p1.y}
                stroke="#facc15"
                strokeWidth="2"
                strokeDasharray="2 2"
              />
              <line
                x1={p3.x}
                y1={p3.y}
                x2={p2.x}
                y2={p2.y}
                stroke="#06b6d4"
                strokeWidth="2"
                strokeDasharray="2 2"
              />

              {/* Curve */}
              {activeTab === 'value' ? (
                <path
                  d={curvePath}
                  fill="none"
                  stroke="url(#curveGradientEM)"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                />
              ) : (
                <path
                  d={speedPath}
                  fill="none"
                  stroke="url(#speedGradientEM)"
                  strokeWidth="3"
                  strokeLinecap="round"
                />
              )}

              {/* Endpoints */}
              <circle cx={p0.x} cy={p0.y} r="5" fill="#facc15" />
              <circle cx={p3.x} cy={p3.y} r="5" fill="#06b6d4" />

              {/* Tangent Handles */}
              <circle
                cx={p1.x}
                cy={p1.y}
                r="7"
                fill="#facc15"
                stroke="#ffffff"
                strokeWidth="2"
                className="cursor-grab active:cursor-grabbing hover:scale-125 transition-transform"
                onPointerDown={(e) => handlePointerDown('h1', e)}
              />
              <circle
                cx={p2.x}
                cy={p2.y}
                r="7"
                fill="#06b6d4"
                stroke="#ffffff"
                strokeWidth="2"
                className="cursor-grab active:cursor-grabbing hover:scale-125 transition-transform"
                onPointerDown={(e) => handlePointerDown('h2', e)}
              />
            </svg>
          </div>

          {/* Coordinate Readout */}
          <div className="flex items-center justify-between w-full mt-2 text-[11px] text-slate-400 font-mono">
            <div>
              Handle 1: <span className="text-yellow-400">({handle.x1.toFixed(2)}, {handle.y1.toFixed(2)})</span>
            </div>
            <div>
              Handle 2: <span className="text-cyan-400">({handle.x2.toFixed(2)}, {handle.y2.toFixed(2)})</span>
            </div>
          </div>

          {/* Preview Slider */}
          <div className="w-full mt-2.5 p-2 bg-[#0e1117] border border-[#1d222e] rounded-lg">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-slate-400">Velocity Progress</span>
              <span className="font-mono text-yellow-400">
                {(previewProgress * 100).toFixed(0)}%
              </span>
            </div>
            <div className="relative w-full h-2.5 bg-[#171b26] rounded-full overflow-hidden">
              <div
                className="absolute top-0 bottom-0 w-4 h-full bg-gradient-to-r from-yellow-400 to-cyan-400 rounded-full"
                style={{
                  left: `${Math.min(96, Math.max(0, previewProgress * 96))}%`,
                }}
              />
            </div>
          </div>
        </div>

        {/* Right: Easy Motion Curve Presets (5 cols) */}
        <div className="md:col-span-5 flex flex-col justify-between space-y-2.5">
          <div>
            <div className="text-xs font-bold text-slate-200 mb-2 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-yellow-400" />
              <span>Easy Motion Curves</span>
            </div>

            <div className="space-y-1">
              <button
                onClick={() => applyPreset('easeInOut')}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center justify-between ${
                  activeCurveType === 'easeInOut'
                    ? 'bg-yellow-400/20 text-yellow-300 border border-yellow-400/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#161a25]'
                }`}
              >
                <span>Easy Motion Smooth Ease</span>
                {activeCurveType === 'easeInOut' && <Check className="w-3 h-3 text-yellow-400" />}
              </button>

              <button
                onClick={() => applyPreset('velocityPop')}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center justify-between ${
                  activeCurveType === 'velocityPop'
                    ? 'bg-yellow-400/20 text-yellow-300 border border-yellow-400/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#161a25]'
                }`}
              >
                <span>Easy Motion Velocity Pop</span>
                {activeCurveType === 'velocityPop' && <Check className="w-3 h-3 text-yellow-400" />}
              </button>

              <button
                onClick={() => applyPreset('bounce')}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center justify-between ${
                  activeCurveType === 'bounce'
                    ? 'bg-yellow-400/20 text-yellow-300 border border-yellow-400/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#161a25]'
                }`}
              >
                <span>Easy Motion Spring Bounce</span>
                {activeCurveType === 'bounce' && <Check className="w-3 h-3 text-yellow-400" />}
              </button>

              <button
                onClick={() => applyPreset('easeOut')}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center justify-between ${
                  activeCurveType === 'easeOut'
                    ? 'bg-yellow-400/20 text-yellow-300 border border-yellow-400/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#161a25]'
                }`}
              >
                <span>Easy Motion Fast Decel</span>
                {activeCurveType === 'easeOut' && <Check className="w-3 h-3 text-yellow-400" />}
              </button>

              <button
                onClick={() => applyPreset('linear')}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center justify-between ${
                  activeCurveType === 'linear'
                    ? 'bg-yellow-400/20 text-yellow-300 border border-yellow-400/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#161a25]'
                }`}
              >
                <span>Easy Motion Linear</span>
                {activeCurveType === 'linear' && <Check className="w-3 h-3 text-yellow-400" />}
              </button>
            </div>
          </div>

          {/* Active target keyframe status */}
          <div className="p-2.5 bg-[#0e1117] border border-[#1d222e] rounded-xl text-xs space-y-1">
            <div className="text-slate-400">Selected Clip:</div>
            <div className="font-semibold text-white truncate">
              {selectedLayer ? selectedLayer.name : 'Select a keyframe on timeline'}
            </div>
            {selectedKeyframe && (
              <div className="text-slate-400 flex items-center justify-between font-mono pt-1">
                <span>Property:</span>
                <span className="text-yellow-400">{selectedKeyframe.property}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
