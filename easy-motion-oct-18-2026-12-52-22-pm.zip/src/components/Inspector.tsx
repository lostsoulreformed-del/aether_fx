import React, { useState } from 'react';
import {
  Sliders,
  Sparkles,
  Link2,
  Unlink2,
  Clock,
  Diamond,
  ChevronLeft,
  ChevronRight,
  Activity,
  Layers,
  Zap,
  Trash2,
  Eye,
  EyeOff,
  MoveUp,
  MoveDown,
  Plus,
  Type,
  Palette,
} from 'lucide-react';
import {
  Layer,
  Keyframe,
  KeyframableProperty,
  TemporalInterpolation,
  BlendMode,
} from '../types/editor';
import { BUILTIN_EFFECTS } from '../utils/effectsLibrary';
import { SPEED_RAMP_PRESETS } from '../utils/presets';

interface InspectorProps {
  layer: Layer | null;
  allLayers: Layer[];
  currentTime: number;
  onUpdateLayer: (layerId: string, updates: Partial<Layer>) => void;
  onToggleStopwatch: (layerId: string, property: KeyframableProperty) => void;
  onAddOrRemoveKeyframe: (layerId: string, property: KeyframableProperty) => void;
  onUpdateKeyframeInterpolation: (
    layerId: string,
    keyframeId: string,
    interpolation: TemporalInterpolation
  ) => void;
  onSeekToKeyframe: (time: number) => void;
  onOpenGraphEditor: (keyframeId?: string) => void;
  onOpenEffectsLibrary: () => void;
}

export const Inspector: React.FC<InspectorProps> = ({
  layer,
  allLayers,
  currentTime,
  onUpdateLayer,
  onToggleStopwatch,
  onAddOrRemoveKeyframe,
  onUpdateKeyframeInterpolation,
  onSeekToKeyframe,
  onOpenGraphEditor,
  onOpenEffectsLibrary,
}) => {
  const [activeTab, setActiveTab] = useState<'transform' | 'blending' | 'effects' | 'velocity'>('transform');
  const [uniformScale, setUniformScale] = useState(true);

  if (!layer) {
    return (
      <div className="w-80 bg-[#0e1118] border-l border-[#1e2330] p-6 flex flex-col items-center justify-center text-center text-slate-400 select-none">
        <Sliders className="w-8 h-8 text-slate-600 mb-3" />
        <h3 className="text-sm font-semibold text-slate-300">No Layer Selected</h3>
        <p className="text-xs text-slate-500 mt-1 max-w-[200px]">
          Click any clip on the timeline or preview screen to edit transforms, keyframes, and effects.
        </p>
      </div>
    );
  }

  // Helper to find keyframe at or near current time (within 0.05s)
  const getKeyframeAtCurrentTime = (prop: KeyframableProperty): Keyframe | undefined => {
    return layer.keyframes.find(
      (k) => k.property === prop && Math.abs(k.time - currentTime) < 0.05
    );
  };

  // Helper for prev/next keyframe navigation
  const getPrevKeyframe = (prop: KeyframableProperty) => {
    const kfs = layer.keyframes
      .filter((k) => k.property === prop && k.time < currentTime - 0.05)
      .sort((a, b) => b.time - a.time);
    return kfs[0];
  };

  const getNextKeyframe = (prop: KeyframableProperty) => {
    const kfs = layer.keyframes
      .filter((k) => k.property === prop && k.time > currentTime + 0.05)
      .sort((a, b) => a.time - b.time);
    return kfs[0];
  };

  // Render a keyframable property row with stopwatch, prev/diamond/next, and slider
  const renderKeyframableRow = (
    label: string,
    property: KeyframableProperty,
    value: number,
    min: number,
    max: number,
    step: number,
    onChange: (val: number) => void,
    unit: string = ''
  ) => {
    const isStopwatchActive = !!layer.activeStopwatches[property];
    const kfCurrent = getKeyframeAtCurrentTime(property);
    const prevKf = getPrevKeyframe(property);
    const nextKf = getNextKeyframe(property);

    return (
      <div className="space-y-1.5 p-2 bg-[#121620] border border-[#1d2331] rounded-lg">
        <div className="flex items-center justify-between text-xs">
          {/* Label + Stopwatch */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onToggleStopwatch(layer.id, property)}
              className={`p-1 rounded transition-colors ${
                isStopwatchActive
                  ? 'text-cyan-400 bg-cyan-950/60 border border-cyan-500/40'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
              title={
                isStopwatchActive
                  ? 'Stopwatch Active: Edits create keyframes'
                  : 'Enable Keyframe Stopwatch'
              }
            >
              <Clock className="w-3.5 h-3.5" />
            </button>
            <span className="font-medium text-slate-200">{label}</span>
          </div>

          {/* Keyframe Navigation Cluster */}
          {isStopwatchActive && (
            <div className="flex items-center gap-1">
              <button
                onClick={() => prevKf && onSeekToKeyframe(prevKf.time)}
                disabled={!prevKf}
                className="p-0.5 text-slate-400 hover:text-white disabled:opacity-20"
                title="Go to Previous Keyframe"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => onAddOrRemoveKeyframe(layer.id, property)}
                className={`p-0.5 rounded transition-colors ${
                  kfCurrent
                    ? 'text-amber-400'
                    : 'text-slate-500 hover:text-slate-300'
                }`}
                title={kfCurrent ? 'Remove Keyframe at Playhead' : 'Add Keyframe at Playhead'}
              >
                <Diamond className={`w-3.5 h-3.5 ${kfCurrent ? 'fill-amber-400' : ''}`} />
              </button>

              <button
                onClick={() => nextKf && onSeekToKeyframe(nextKf.time)}
                disabled={!nextKf}
                className="p-0.5 text-slate-400 hover:text-white disabled:opacity-20"
                title="Go to Next Keyframe"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Numeric Readout */}
          <span className="font-mono text-slate-400 text-[11px]">
            {Math.round(value * 10) / 10}
            {unit}
          </span>
        </div>

        {/* Value Slider */}
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="w-full accent-violet-500 h-1.5 bg-[#1b202c] rounded cursor-pointer"
        />

        {/* If a keyframe exists at current time, show its interpolation type */}
        {kfCurrent && (
          <div className="flex items-center justify-between pt-1 border-t border-[#1a1f2b] text-[11px]">
            <span className="text-slate-400">Interpolation:</span>
            <div className="flex items-center gap-1.5">
              <select
                value={kfCurrent.interpolation}
                onChange={(e) =>
                  onUpdateKeyframeInterpolation(
                    layer.id,
                    kfCurrent.id,
                    e.target.value as TemporalInterpolation
                  )
                }
                className="bg-[#181d29] border border-[#273042] rounded px-1.5 py-0.5 text-slate-300 text-[10px] focus:outline-none"
              >
                <option value="bezier">Bezier Curve</option>
                <option value="linear">Linear</option>
                <option value="hold">Hold (Freeze)</option>
              </select>

              {kfCurrent.interpolation === 'bezier' && (
                <button
                  onClick={() => onOpenGraphEditor(kfCurrent.id)}
                  className="px-1.5 py-0.5 bg-violet-600/30 hover:bg-violet-600 text-violet-300 hover:text-white rounded text-[10px] flex items-center gap-1 transition-colors"
                  title="Open Bezier Graph Editor"
                >
                  <Activity className="w-2.5 h-2.5" />
                  <span>Graph</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="w-80 bg-[#0e1118] border-l border-[#1e2330] flex flex-col shrink-0 select-none text-slate-200">
      {/* Header */}
      <div className="px-4 py-3 border-b border-[#1c2230] flex items-center justify-between bg-[#11141c]">
        <div className="truncate">
          <div className="text-xs font-bold text-white truncate">{layer.name}</div>
          <div className="text-[11px] text-slate-400 font-mono">
            {layer.type.toUpperCase()} · Track {layer.trackIndex + 1}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center px-2 py-1.5 bg-[#12151e] border-b border-[#1c2230] text-xs">
        <button
          onClick={() => setActiveTab('transform')}
          className={`flex-1 py-1 text-center font-medium rounded transition-colors ${
            activeTab === 'transform'
              ? 'bg-violet-600 text-white'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Transform
        </button>
        <button
          onClick={() => setActiveTab('blending')}
          className={`flex-1 py-1 text-center font-medium rounded transition-colors ${
            activeTab === 'blending'
              ? 'bg-violet-600 text-white'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Blending
        </button>
        <button
          onClick={() => setActiveTab('velocity')}
          className={`flex-1 py-1 text-center font-medium rounded transition-colors ${
            activeTab === 'velocity'
              ? 'bg-violet-600 text-white'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Velocity
        </button>
        <button
          onClick={() => setActiveTab('effects')}
          className={`flex-1 py-1 text-center font-medium rounded transition-colors ${
            activeTab === 'effects'
              ? 'bg-violet-600 text-white'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          VFX ({layer.effects.length})
        </button>
      </div>

      {/* Tab Contents */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {/* TAB 1: TRANSFORM & KEYFRAMING */}
        {activeTab === 'transform' && (
          <div className="space-y-3">
            {/* Position X */}
            {renderKeyframableRow(
              'Position X',
              'position.x',
              layer.transform.position.x,
              -600,
              600,
              1,
              (val) =>
                onUpdateLayer(layer.id, {
                  transform: {
                    ...layer.transform,
                    position: { ...layer.transform.position, x: val },
                  },
                }),
              'px'
            )}

            {/* Position Y */}
            {renderKeyframableRow(
              'Position Y',
              'position.y',
              layer.transform.position.y,
              -600,
              600,
              1,
              (val) =>
                onUpdateLayer(layer.id, {
                  transform: {
                    ...layer.transform,
                    position: { ...layer.transform.position, y: val },
                  },
                }),
              'px'
            )}

            {/* Scale X */}
            {renderKeyframableRow(
              uniformScale ? 'Scale (Uniform)' : 'Scale X',
              'scale.x',
              layer.transform.scale.x,
              0.1,
              3.0,
              0.05,
              (val) =>
                onUpdateLayer(layer.id, {
                  transform: {
                    ...layer.transform,
                    scale: uniformScale
                      ? { x: val, y: val }
                      : { ...layer.transform.scale, x: val },
                  },
                }),
              'x'
            )}

            {/* Scale Y (if not uniform) */}
            {!uniformScale &&
              renderKeyframableRow(
                'Scale Y',
                'scale.y',
                layer.transform.scale.y,
                0.1,
                3.0,
                0.05,
                (val) =>
                  onUpdateLayer(layer.id, {
                    transform: {
                      ...layer.transform,
                      scale: { ...layer.transform.scale, y: val },
                    },
                  }),
                'x'
              )}

            {/* Rotation */}
            {renderKeyframableRow(
              'Rotation',
              'rotation',
              layer.transform.rotation,
              -180,
              180,
              1,
              (val) =>
                onUpdateLayer(layer.id, {
                  transform: { ...layer.transform, rotation: val },
                }),
              '°'
            )}

            {/* Opacity */}
            {renderKeyframableRow(
              'Opacity',
              'opacity',
              layer.opacity,
              0,
              100,
              1,
              (val) => onUpdateLayer(layer.id, { opacity: val }),
              '%'
            )}

            {/* Blur & Saturation */}
            {renderKeyframableRow(
              'Blur',
              'blur',
              layer.blur || 0,
              0,
              80,
              1,
              (val) => onUpdateLayer(layer.id, { blur: val }),
              'px'
            )}

            {renderKeyframableRow(
              'Saturation',
              'saturation',
              layer.saturation ?? 100,
              0,
              200,
              1,
              (val) => onUpdateLayer(layer.id, { saturation: val }),
              '%'
            )}
          </div>
        )}

        {/* TAB 2: BLENDING & PARENTING (After Effects Freedom) */}
        {activeTab === 'blending' && (
          <div className="space-y-4">
            {/* Blend Mode */}
            <div className="p-3 bg-[#121620] border border-[#1d2331] rounded-lg space-y-2">
              <label className="text-xs font-semibold text-slate-200">
                Blend Mode
              </label>
              <select
                value={layer.blendMode}
                onChange={(e) =>
                  onUpdateLayer(layer.id, { blendMode: e.target.value as BlendMode })
                }
                className="w-full bg-[#181d29] border border-[#273042] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-violet-500"
              >
                <option value="normal">Normal</option>
                <option value="screen">Screen (Lighten)</option>
                <option value="multiply">Multiply (Darken)</option>
                <option value="add">Add (Linear Dodge)</option>
                <option value="color-dodge">Color Dodge</option>
                <option value="overlay">Overlay</option>
                <option value="soft-light">Soft Light</option>
                <option value="difference">Difference</option>
              </select>
            </div>

            {/* Parent Layer (AE Parenting) */}
            <div className="p-3 bg-[#121620] border border-[#1d2331] rounded-lg space-y-2">
              <div className="flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-violet-400" />
                <label className="text-xs font-semibold text-slate-200">
                  Parent Layer (Inherit Transforms)
                </label>
              </div>
              <p className="text-[11px] text-slate-400">
                Link this layer to follow the position, rotation, and scale of a parent.
              </p>
              <select
                value={layer.parentId || ''}
                onChange={(e) =>
                  onUpdateLayer(layer.id, { parentId: e.target.value || null })
                }
                className="w-full bg-[#181d29] border border-[#273042] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-violet-500"
              >
                <option value="">None (Root)</option>
                {allLayers
                  .filter((l) => l.id !== layer.id)
                  .map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name}
                    </option>
                  ))}
              </select>
            </div>

            {/* Motion Blur */}
            <div className="p-3 bg-[#121620] border border-[#1d2331] rounded-lg flex items-center justify-between">
              <div>
                <div className="text-xs font-semibold text-slate-200">
                  Motion Blur
                </div>
                <div className="text-[11px] text-slate-400">
                  Sub-frame shutter angle blur
                </div>
              </div>
              <input
                type="checkbox"
                checked={layer.motionBlur}
                onChange={(e) =>
                  onUpdateLayer(layer.id, { motionBlur: e.target.checked })
                }
                className="w-4 h-4 accent-violet-500 rounded bg-[#181d29] cursor-pointer"
              />
            </div>
          </div>
        )}

        {/* TAB 3: VELOCITY SPEED RAMP (CapCut style) */}
        {activeTab === 'velocity' && (
          <div className="space-y-3">
            <div className="p-3 bg-[#121620] border border-[#1d2331] rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-white">
                  CapCut Velocity Curve
                </span>
                <input
                  type="checkbox"
                  checked={layer.speedRamp?.enabled ?? false}
                  onChange={(e) => {
                    const currentRamp = layer.speedRamp || SPEED_RAMP_PRESETS.hero;
                    onUpdateLayer(layer.id, {
                      speedRamp: { ...currentRamp, enabled: e.target.checked },
                    });
                  }}
                  className="w-4 h-4 accent-amber-500 rounded"
                />
              </div>
              <p className="text-[11px] text-slate-400">
                Smooth speed ramp transition between hyper-fast zooms and dramatic slow-motion.
              </p>
            </div>

            {/* Preset Curves */}
            <div className="space-y-2">
              <span className="text-xs font-medium text-slate-300">
                Velocity Presets
              </span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() =>
                    onUpdateLayer(layer.id, {
                      speedRamp: SPEED_RAMP_PRESETS.hero,
                    })
                  }
                  className="p-2 text-xs text-left bg-[#141822] hover:bg-[#1e2332] border border-[#242c3c] rounded-lg transition-colors"
                >
                  <div className="font-semibold text-amber-400">Hero Ramp</div>
                  <div className="text-[10px] text-slate-400">Fast → Slow → Fast</div>
                </button>

                <button
                  onClick={() =>
                    onUpdateLayer(layer.id, {
                      speedRamp: SPEED_RAMP_PRESETS.montage,
                    })
                  }
                  className="p-2 text-xs text-left bg-[#141822] hover:bg-[#1e2332] border border-[#242c3c] rounded-lg transition-colors"
                >
                  <div className="font-semibold text-amber-400">Montage</div>
                  <div className="text-[10px] text-slate-400">Slow → Fast Zoom</div>
                </button>

                <button
                  onClick={() =>
                    onUpdateLayer(layer.id, {
                      speedRamp: SPEED_RAMP_PRESETS.bullet,
                    })
                  }
                  className="p-2 text-xs text-left bg-[#141822] hover:bg-[#1e2332] border border-[#242c3c] rounded-lg transition-colors"
                >
                  <div className="font-semibold text-amber-400">Bullet Time</div>
                  <div className="text-[10px] text-slate-400">Ultra slow-mo freeze</div>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: EFFECTS STACK */}
        {activeTab === 'effects' && (
          <div className="space-y-3">
            {/* Add Effect Button */}
            <button
              onClick={onOpenEffectsLibrary}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-semibold bg-violet-600 hover:bg-violet-500 text-white shadow-xs transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Browse Effects Library</span>
            </button>

            {/* Active Effects List */}
            {layer.effects.length === 0 ? (
              <div className="p-4 bg-[#11141c] border border-[#1d2331] rounded-lg text-center text-xs text-slate-500">
                No effects added yet. Click above to browse over 10 built-in shaders and transitions.
              </div>
            ) : (
              layer.effects.map((eff, index) => {
                const def = BUILTIN_EFFECTS.find((b) => b.type === eff.type);

                return (
                  <div
                    key={eff.id}
                    className="p-3 bg-[#131722] border border-[#22293b] rounded-lg space-y-2.5"
                  >
                    {/* Effect Header */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            const updated = layer.effects.map((e) =>
                              e.id === eff.id ? { ...e, enabled: !e.enabled } : e
                            );
                            onUpdateLayer(layer.id, { effects: updated });
                          }}
                          className={`p-1 rounded ${
                            eff.enabled ? 'text-cyan-400' : 'text-slate-600'
                          }`}
                        >
                          {eff.enabled ? (
                            <Eye className="w-3.5 h-3.5" />
                          ) : (
                            <EyeOff className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <span className="text-xs font-semibold text-white">
                          {eff.name}
                        </span>
                      </div>

                      <div className="flex items-center gap-1">
                        {/* Move Up */}
                        <button
                          onClick={() => {
                            if (index > 0) {
                              const list = [...layer.effects];
                              const temp = list[index - 1];
                              list[index - 1] = list[index];
                              list[index] = temp;
                              onUpdateLayer(layer.id, { effects: list });
                            }
                          }}
                          disabled={index === 0}
                          className="p-1 text-slate-400 hover:text-white disabled:opacity-20"
                          title="Move Up"
                        >
                          <MoveUp className="w-3 h-3" />
                        </button>

                        {/* Move Down */}
                        <button
                          onClick={() => {
                            if (index < layer.effects.length - 1) {
                              const list = [...layer.effects];
                              const temp = list[index + 1];
                              list[index + 1] = list[index];
                              list[index] = temp;
                              onUpdateLayer(layer.id, { effects: list });
                            }
                          }}
                          disabled={index === layer.effects.length - 1}
                          className="p-1 text-slate-400 hover:text-white disabled:opacity-20"
                          title="Move Down"
                        >
                          <MoveDown className="w-3 h-3" />
                        </button>

                        {/* Delete */}
                        <button
                          onClick={() => {
                            const updated = layer.effects.filter(
                              (e) => e.id !== eff.id
                            );
                            onUpdateLayer(layer.id, { effects: updated });
                          }}
                          className="p-1 text-slate-400 hover:text-rose-400"
                          title="Remove Effect"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    {/* Parameter Controls */}
                    {def && (
                      <div className="space-y-2 pt-1 border-t border-[#1c2230]">
                        {def.paramControls.map((ctrl) => {
                          const currentVal =
                            eff.params[ctrl.key] ??
                            def.defaultParams[ctrl.key] ??
                            0;

                          return (
                            <div key={ctrl.key} className="space-y-1">
                              <div className="flex justify-between text-[11px] text-slate-400">
                                <span>{ctrl.label}</span>
                                <span className="font-mono text-cyan-400">
                                  {currentVal}
                                </span>
                              </div>
                              <input
                                type="range"
                                min={ctrl.min ?? 0}
                                max={ctrl.max ?? 100}
                                step={ctrl.step ?? 1}
                                value={Number(currentVal)}
                                onChange={(e) => {
                                  const updated = layer.effects.map((item) =>
                                    item.id === eff.id
                                      ? {
                                          ...item,
                                          params: {
                                            ...item.params,
                                            [ctrl.key]: Number(e.target.value),
                                          },
                                        }
                                      : item
                                  );
                                  onUpdateLayer(layer.id, { effects: updated });
                                }}
                                className="w-full accent-cyan-400 h-1 bg-[#1b202c] rounded cursor-pointer"
                              />
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        )}
      </div>
    </div>
  );
};
