import React, { useRef } from 'react';
import {
  Upload,
  Video,
  Image as ImageIcon,
  Type,
  Square,
  Circle,
  Plus,
  Layers,
  Sparkles,
} from 'lucide-react';
import { STOCK_MEDIA } from '../utils/presets';
import { Layer, LayerType } from '../types/editor';

interface MediaLibraryProps {
  onAddLayer: (newLayer: Partial<Layer>) => void;
  onClose?: () => void;
}

export const MediaLibrary: React.FC<MediaLibraryProps> = ({
  onAddLayer,
  onClose,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const objectUrl = URL.createObjectURL(file);
    const isVideo = file.type.startsWith('video');
    const isAudio = file.type.startsWith('audio');

    onAddLayer({
      name: file.name.replace(/\.[^/.]+$/, ''),
      type: isAudio ? 'audio' : isVideo ? 'video' : 'image',
      sourceUrl: objectUrl,
      duration: isAudio ? 12 : 6,
    });
  };

  return (
    <div className="bg-[#11141c] border border-[#232938] rounded-xl p-5 shadow-2xl w-full max-w-xl select-none text-slate-200">
      <div className="flex items-center justify-between pb-3 border-b border-[#202636]">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-violet-400" />
          <h2 className="text-sm font-bold text-white tracking-tight">
            Media & Asset Library
          </h2>
        </div>
      </div>

      <div className="mt-4 space-y-4">
        {/* Upload Custom Media */}
        <div>
          <span className="text-xs font-semibold text-slate-300">
            Import Local Footage
          </span>
          <div
            onClick={() => fileInputRef.current?.click()}
            className="mt-2 border-2 border-dashed border-[#262e42] hover:border-violet-500 rounded-xl p-5 flex flex-col items-center justify-center cursor-pointer transition-colors bg-[#131722]"
          >
            <Upload className="w-6 h-6 text-violet-400 mb-2" />
            <span className="text-xs font-medium text-slate-200">
              Click to browse or drop video, image, or audio files
            </span>
            <span className="text-[11px] text-slate-500 mt-1">
              Supports MP4, WebM, PNG, JPEG, MP3, WAV
            </span>
            <input
              ref={fileInputRef}
              type="file"
              accept="video/*,image/*,audio/*"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>
        </div>

        {/* Quick Creative Layers */}
        <div>
          <span className="text-xs font-semibold text-slate-300">
            Create Motion Graphic Layers
          </span>
          <div className="grid grid-cols-3 gap-2 mt-2">
            <button
              onClick={() =>
                onAddLayer({
                  name: 'Kinetic Text',
                  type: 'text',
                  text: 'GLITCH MOTION',
                  fontSize: 52,
                  fillColor: '#ffffff',
                  strokeColor: '#06b6d4',
                  strokeWidth: 2,
                  duration: 5,
                })
              }
              className="p-3 bg-[#151924] hover:bg-[#1e2333] border border-[#22293b] rounded-lg text-left flex flex-col items-center justify-center gap-1.5 transition-colors"
            >
              <Type className="w-5 h-5 text-violet-400" />
              <span className="text-xs font-medium text-slate-200">Text Layer</span>
            </button>

            <button
              onClick={() =>
                onAddLayer({
                  name: 'Neon Circle Shape',
                  type: 'shape',
                  shapeType: 'circle',
                  fillColor: '#8b5cf6',
                  duration: 5,
                })
              }
              className="p-3 bg-[#151924] hover:bg-[#1e2333] border border-[#22293b] rounded-lg text-left flex flex-col items-center justify-center gap-1.5 transition-colors"
            >
              <Circle className="w-5 h-5 text-pink-400" />
              <span className="text-xs font-medium text-slate-200">Shape Layer</span>
            </button>

            <button
              onClick={() =>
                onAddLayer({
                  name: 'Null Camera Controller',
                  type: 'null',
                  duration: 10,
                })
              }
              className="p-3 bg-[#151924] hover:bg-[#1e2333] border border-[#22293b] rounded-lg text-left flex flex-col items-center justify-center gap-1.5 transition-colors"
            >
              <Layers className="w-5 h-5 text-cyan-400" />
              <span className="text-xs font-medium text-slate-200">Null Object</span>
            </button>
          </div>
        </div>

        {/* Built-in 4K Cinematic Stock Media */}
        <div>
          <span className="text-xs font-semibold text-slate-300">
            Demo 4K Stock Clips
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-2">
            {STOCK_MEDIA.map((stock) => (
              <div
                key={stock.id}
                onClick={() =>
                  onAddLayer({
                    name: stock.name,
                    type: 'image',
                    sourceUrl: stock.url,
                    duration: stock.duration,
                  })
                }
                className="group relative rounded-lg overflow-hidden border border-[#232938] hover:border-violet-500 cursor-pointer transition-all aspect-video bg-[#0c0e14]"
              >
                <img
                  src={stock.url}
                  alt={stock.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-2">
                  <span className="text-[11px] font-semibold text-white leading-tight">
                    {stock.name}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
