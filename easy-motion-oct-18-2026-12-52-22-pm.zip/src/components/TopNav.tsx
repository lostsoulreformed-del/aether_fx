import React from 'react';
import {
  Sparkles,
  Download,
  RotateCcw,
  Upload,
  Layers,
  Activity,
  Smartphone,
  HelpCircle,
} from 'lucide-react';
import { ProjectSettings } from '../types/editor';

interface TopNavProps {
  project: ProjectSettings;
  activeView: 'workstation' | 'graph' | 'topaz';
  setActiveView: (view: 'workstation' | 'graph' | 'topaz') => void;
  onExportClick: () => void;
  onResetDemo: () => void;
  onImportClick: () => void;
  onHelpClick: () => void;
  onApkClick: () => void;
  onAspectRatioChange: (ratio: '16:9' | '9:16' | '1:1') => void;
  topazEnabled: boolean;
}

export const TopNav: React.FC<TopNavProps> = ({
  project,
  activeView,
  setActiveView,
  onExportClick,
  onResetDemo,
  onImportClick,
  onHelpClick,
  onApkClick,
  onAspectRatioChange,
  topazEnabled,
}) => {
  return (
    <header className="flex items-center justify-between gap-8 px-5 py-2.5 bg-[#0e1015] border-b border-[#1f242e] h-14 shrink-0 select-none z-30">
      {/* Zone 1: Brand Wordmark with Awesome Yellow-Black Logo */}
      <div className="flex items-center gap-3 shrink-0">
        <a href="/" className="flex items-center gap-2.5 text-slate-100 group">
          <div className="w-8 h-8 rounded-lg overflow-hidden border border-yellow-400/40 p-[1px] bg-black shadow-sm flex items-center justify-center shrink-0">
            <img
              src="/logo.jpg"
              alt="Easy Motion Logo"
              className="w-full h-full object-cover rounded-[6px]"
            />
          </div>
          <span className="text-base font-bold tracking-tight text-white whitespace-nowrap">
            Easy Motion
          </span>
        </a>

        {/* Aspect Ratio Selector */}
        <div className="hidden sm:flex items-center ml-4 bg-[#141720] border border-[#232938] rounded-md p-0.5 text-xs">
          <button
            onClick={() => onAspectRatioChange('16:9')}
            className={`px-2 py-1 rounded font-medium transition-colors ${
              project.aspectRatio === '16:9'
                ? 'bg-yellow-400 text-slate-950 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            16:9
          </button>
          <button
            onClick={() => onAspectRatioChange('9:16')}
            className={`px-2 py-1 rounded font-medium transition-colors ${
              project.aspectRatio === '9:16'
                ? 'bg-yellow-400 text-slate-950 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            9:16
          </button>
          <button
            onClick={() => onAspectRatioChange('1:1')}
            className={`px-2 py-1 rounded font-medium transition-colors ${
              project.aspectRatio === '1:1'
                ? 'bg-yellow-400 text-slate-950 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            1:1
          </button>
        </div>
      </div>

      {/* Zone 2: Navigation / Studio View Tabs */}
      <nav className="flex items-center gap-1.5 text-xs font-medium">
        <button
          onClick={() => setActiveView('workstation')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-all whitespace-nowrap ${
            activeView === 'workstation'
              ? 'bg-[#1e2330] text-yellow-300 shadow-xs border border-yellow-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-[#151821]'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Workstation</span>
        </button>

        <button
          onClick={() => setActiveView('graph')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-all whitespace-nowrap ${
            activeView === 'graph'
              ? 'bg-[#1e2330] text-yellow-300 shadow-xs border border-yellow-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-[#151821]'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Graph Curves</span>
        </button>

        <button
          onClick={() => setActiveView('topaz')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-all whitespace-nowrap ${
            activeView === 'topaz'
              ? 'bg-[#1e2330] text-cyan-400 shadow-xs border border-cyan-500/20'
              : 'text-slate-400 hover:text-cyan-300 hover:bg-[#151821]'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>Topaz AI Lab</span>
          {topazEnabled && (
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
          )}
        </button>
      </nav>

      {/* Zone 3: Primary Action & Utilities */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={onImportClick}
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-slate-300 bg-[#161922] hover:bg-[#202534] border border-[#262c3c] rounded-md transition-colors"
          title="Import Media (Video/Audio/Image)"
        >
          <Upload className="w-3.5 h-3.5" />
          <span className="whitespace-nowrap">Import</span>
        </button>

        <button
          onClick={onResetDemo}
          className="p-1.5 text-slate-400 hover:text-slate-200 bg-[#161922] hover:bg-[#202534] border border-[#262c3c] rounded-md transition-colors"
          title="Reset Demo Scene"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={onHelpClick}
          className="p-1.5 text-slate-400 hover:text-slate-200 bg-[#161922] hover:bg-[#202534] border border-[#262c3c] rounded-md transition-colors"
          title="Keyboard Shortcuts & Workflow Guide"
        >
          <HelpCircle className="w-3.5 h-3.5" />
        </button>

        {/* Download APK / Install on Phone */}
        <button
          onClick={onApkClick}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-yellow-300 bg-[#1e1c12] hover:bg-[#2a2618] border border-yellow-400/40 rounded-md transition-colors whitespace-nowrap active:scale-[0.98]"
          title="Install Easy Motion APK on Android / Device"
        >
          <Smartphone className="w-3.5 h-3.5 text-yellow-400" />
          <span>Install APK</span>
        </button>

        {/* Export 4K Master */}
        <button
          onClick={onExportClick}
          className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold text-slate-950 bg-gradient-to-r from-yellow-400 to-amber-300 hover:opacity-95 rounded-md shadow-sm transition-all whitespace-nowrap active:scale-[0.98]"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export 4K Master</span>
        </button>
      </div>
    </header>
  );
};
