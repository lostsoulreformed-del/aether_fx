import React from 'react';
import {
  Sliders,
  Activity,
  Sparkles,
  Plus,
  Zap,
} from 'lucide-react';

export type MobileTab = 'none' | 'transform' | 'curves' | 'effects' | 'topaz' | 'add';

interface MobileBottomNavProps {
  activeTab: MobileTab;
  onSelectTab: (tab: MobileTab) => void;
  hasSelectedLayer: boolean;
  topazEnabled: boolean;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  onSelectTab,
  hasSelectedLayer,
  topazEnabled,
}) => {
  const tabs = [
    {
      id: 'transform' as MobileTab,
      label: 'Transform',
      icon: <Sliders className="w-5 h-5" />,
      requiresLayer: true,
    },
    {
      id: 'curves' as MobileTab,
      label: 'Curves',
      icon: <Activity className="w-5 h-5" />,
      requiresLayer: true,
    },
    {
      id: 'effects' as MobileTab,
      label: 'Effects',
      icon: <Zap className="w-5 h-5" />,
      requiresLayer: true,
    },
    {
      id: 'topaz' as MobileTab,
      label: 'Topaz AI',
      icon: <Sparkles className="w-5 h-5" />,
      badge: topazEnabled,
    },
    {
      id: 'add' as MobileTab,
      label: 'Add Clip',
      icon: <Plus className="w-5 h-5" />,
    },
  ];

  return (
    <nav className="h-16 bg-[#0c0e15] border-t border-[#1e2332] grid grid-cols-5 items-center px-1 z-30 shrink-0 select-none">
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        const isDisabled = tab.requiresLayer && !hasSelectedLayer;

        return (
          <button
            key={tab.id}
            onClick={() => onSelectTab(isActive ? 'none' : tab.id)}
            disabled={isDisabled}
            className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-all relative ${
              isDisabled
                ? 'opacity-30 cursor-not-allowed text-slate-500'
                : isActive
                ? 'text-yellow-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200 active:scale-95'
            }`}
          >
            {/* Active Glow Pill */}
            {isActive && (
              <div className="absolute top-1 w-8 h-1 bg-yellow-400 rounded-full shadow-xs" />
            )}

            <div className="relative">
              {tab.icon}
              {tab.badge && (
                <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-cyan-400 ring-2 ring-[#0c0e15]" />
              )}
            </div>

            <span className="text-[10px] mt-1 tracking-tight font-medium">
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
