import React from 'react';
import {
  Download,
  Smartphone,
  RotateCcw,
  Sparkles,
  Play,
  Pause,
  HelpCircle,
} from 'lucide-react';

interface MobileTopBarProps {
  aspectRatio: '9:16' | '16:9' | '1:1';
  onToggleAspectRatio: () => void;
  onOpenApkModal: () => void;
  onOpenExportModal: () => void;
  onResetDemo: () => void;
  currentTime: number;
}

export const MobileTopBar: React.FC<MobileTopBarProps> = ({
  aspectRatio,
  onToggleAspectRatio,
  onOpenApkModal,
  onOpenExportModal,
  onResetDemo,
  currentTime,
}) => {
  const formatSec = (sec: number) => {
    const s = Math.floor(sec % 60);
    const m = Math.floor(sec / 60);
    const ms = Math.floor((sec % 1) * 10);
    return `${m}:${s.toString().padStart(2, '0')}.${ms}`;
  };

  return (
    <header className="h-14 px-4 bg-[#0a0c12] border-b border-[#1b202e] flex items-center justify-between shrink-0 select-none z-30">
      {/* Brand */}
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-xl overflow-hidden border border-yellow-400/50 bg-black shrink-0 shadow-sm">
          <img
            src="/logo.jpg"
            alt="Easy Motion"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex flex-col">
          <span className="text-sm font-bold tracking-tight text-white leading-none">
            Easy Motion
          </span>
          <span className="text-[10px] text-yellow-400/90 font-mono mt-0.5">
            {formatSec(currentTime)}
          </span>
        </div>
      </div>

      {/* Middle: Aspect Ratio Switch */}
      <button
        onClick={onToggleAspectRatio}
        className="px-2.5 py-1 rounded-lg bg-[#151924] border border-[#232a3c] text-xs font-mono font-medium text-slate-300 hover:text-white transition-colors"
        title="Switch Aspect Ratio (9:16 / 16:9)"
      >
        {aspectRatio}
      </button>

      {/* Right Actions: Direct Download APK & Export */}
      <div className="flex items-center gap-2">
        {/* Reset */}
        <button
          onClick={onResetDemo}
          className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-[#151924] transition-colors"
          title="Reset Demo Scene"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        {/* Download APK Button */}
        <button
          onClick={onOpenApkModal}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-[#221f14] hover:bg-[#2c281a] border border-yellow-400 text-yellow-300 shadow-sm transition-all active:scale-95"
          title="Download Easy Motion APK for Android"
        >
          <Smartphone className="w-3.5 h-3.5 text-yellow-400" />
          <span>APK</span>
        </button>

        {/* Export 4K */}
        <button
          onClick={onOpenExportModal}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-yellow-400 hover:bg-yellow-300 text-slate-950 shadow-sm transition-all active:scale-95"
        >
          <Download className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Export</span>
        </button>
      </div>
    </header>
  );
};
