import React, { useState, useRef } from 'react';
import {
  Move,
  RotateCw,
  Maximize2,
  Crosshair,
  Diamond,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Sparkles,
  Link2,
  Unlink2,
} from 'lucide-react';
import { Layer, KeyframableProperty } from '../types/editor';

interface AlightMotionPadProps {
  layer: Layer | null;
  currentTime: number;
  onUpdateTransform: (
    layerId: string,
    transform: Layer['transform']
  ) => void;
  onAddOrRemoveKeyframe: (layerId: string, property: KeyframableProperty) => void;
  onToggleStopwatch: (layerId: string, property: KeyframableProperty) => void;
}

export const AlightMotionPad: React.FC<AlightMotionPadProps> = ({
  layer,
  currentTime,
  onUpdateTransform,
  onAddOrRemoveKeyframe,
  onToggleStopwatch,
}) => {
  const [mode, setMode] = useState<'move' | 'rotate' | 'scale' | 'pivot'>('move');
  const [uniformScale, setUniformScale] = useState(true);
  const padRef = useRef<HTMLDivElement | null>(null);
  const [isInteracting, setIsInteracting] = useState(false);
  const startPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  if (!layer) return null;

  const t = layer.transform;

  // Pointer interaction on 2D trackpad
  const handlePointerDown = (e: React.PointerEvent) => {
    setIsInteracting(true);
    startPosRef.current = { x: e.clientX, y: e.clientY };
    (e.target as Element).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isInteracting) return;
    const dx = e.clientX - startPosRef.current.x;
    const dy = e.clientY - startPosRef.current.y;
    startPosRef.current = { x: e.clientX, y: e.clientY };

    if (mode === 'move') {
      onUpdateTransform(layer.id, {
        ...t,
        position: {
          x: Math.round(t.position.x + dx),
          y: Math.round(t.position.y + dy),
        },
      });
    } else if (mode === 'scale') {
      const scaleDelta = (dx - dy) * 0.005;
      const newScaleX = Math.max(0.1, t.scale.x + scaleDelta);
      const newScaleY = uniformScale ? newScaleX : Math.max(0.1, t.scale.y - dy * 0.005);
      onUpdateTransform(layer.id, {
        ...t,
        scale: { x: newScaleX, y: newScaleY },
      });
    } else if (mode === 'rotate') {
      const rotDelta = dx * 0.6;
      onUpdateTransform(layer.id, {
        ...t,
        rotation: Math.round((t.rotation + rotDelta) % 360),
      });
    } else if (mode === 'pivot') {
      const newAnchorX = Math.max(0, Math.min(1, t.anchorPoint.x + dx * 0.002));
      const newAnchorY = Math.max(0, Math.min(1, t.anchorPoint.y + dy * 0.002));
      onUpdateTransform(layer.id, {
        ...t,
        anchorPoint: { x: newAnchorX, y: newAnchorY },
      });
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsInteracting(false);
    try {
      (e.target as Element).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
  };

  // Nudge buttons
  const nudge = (dx: number, dy: number) => {
    if (mode === 'move') {
      onUpdateTransform(layer.id, {
        ...t,
        position: { x: t.position.x + dx, y: t.position.y + dy },
      });
    } else if (mode === 'rotate') {
      onUpdateTransform(layer.id, {
        ...t,
        rotation: Math.round((t.rotation + dx * 15) % 360),
      });
    } else if (mode === 'scale') {
      const delta = dx * 0.1;
      const sx = Math.max(0.1, t.scale.x + delta);
      onUpdateTransform(layer.id, {
        ...t,
        scale: { x: sx, y: uniformScale ? sx : t.scale.y },
      });
    }
  };

  const currentPropertyKey: KeyframableProperty =
    mode === 'move' ? 'position.x' : mode === 'rotate' ? 'rotation' : 'scale.x';

  const hasKf = layer.keyframes.some(
    (k) => k.property === currentPropertyKey && Math.abs(k.time - currentTime) < 0.05
  );

  return (
    <div className="p-3 bg-[#10141e] border border-[#232a3b] rounded-xl shadow-lg select-none">
      {/* Pad Header & Mode Switcher */}
      <div className="flex items-center justify-between pb-2 border-b border-[#1f2638]">
        <div className="flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-violet-400" />
          <span className="text-xs font-bold text-white tracking-tight">
            AM Move & Transform Pad
          </span>
        </div>

        {/* Keyframe Diamond Shortcut directly inside the pad */}
        <button
          onClick={() => onAddOrRemoveKeyframe(layer.id, currentPropertyKey)}
          className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-mono border transition-colors ${
            hasKf
              ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
              : 'bg-[#181d2a] text-slate-400 hover:text-white border-[#273042]'
          }`}
          title="Add / Remove Keyframe at Playhead"
        >
          <Diamond className={`w-3 h-3 ${hasKf ? 'fill-amber-400' : ''}`} />
          <span>{hasKf ? 'Keyframe Set' : 'Set Keyframe'}</span>
        </button>
      </div>

      {/* Mode Tabs (Position, Rotate, Scale, Anchor) */}
      <div className="grid grid-cols-4 gap-1 mt-2.5">
        <button
          onClick={() => setMode('move')}
          className={`py-1.5 rounded-lg text-xs font-medium flex items-center justify-center gap-1 transition-colors ${
            mode === 'move'
              ? 'bg-violet-600 text-white shadow-xs'
              : 'bg-[#151924] text-slate-400 hover:text-slate-200'
          }`}
        >
          <Move className="w-3 h-3" />
          <span>Move</span>
        </button>

        <button
          onClick={() => setMode('rotate')}
          className={`py-1.5 rounded-lg text-xs font-medium flex items-center justify-center gap-1 transition-colors ${
            mode === 'rotate'
              ? 'bg-violet-600 text-white shadow-xs'
              : 'bg-[#151924] text-slate-400 hover:text-slate-200'
          }`}
        >
          <RotateCw className="w-3 h-3" />
          <span>Rotate</span>
        </button>

        <button
          onClick={() => setMode('scale')}
          className={`py-1.5 rounded-lg text-xs font-medium flex items-center justify-center gap-1 transition-colors ${
            mode === 'scale'
              ? 'bg-violet-600 text-white shadow-xs'
              : 'bg-[#151924] text-slate-400 hover:text-slate-200'
          }`}
        >
          <Maximize2 className="w-3 h-3" />
          <span>Scale</span>
        </button>

        <button
          onClick={() => setMode('pivot')}
          className={`py-1.5 rounded-lg text-xs font-medium flex items-center justify-center gap-1 transition-colors ${
            mode === 'pivot'
              ? 'bg-violet-600 text-white shadow-xs'
              : 'bg-[#151924] text-slate-400 hover:text-slate-200'
          }`}
        >
          <Crosshair className="w-3 h-3" />
          <span>Pivot</span>
        </button>
      </div>

      {/* 2D Interactive Gesture Pad Area */}
      <div className="mt-2.5 relative">
        <div
          ref={padRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="h-28 bg-[#0b0e14] border border-[#1e2535] rounded-xl flex items-center justify-center cursor-crosshair touch-none relative overflow-hidden group"
        >
          {/* Subtle Grid crosshair */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-full h-[1px] bg-white/5" />
            <div className="h-full w-[1px] bg-white/5 absolute" />
          </div>

          {/* Interactive Thumb Puck */}
          <div
            className={`w-10 h-10 rounded-full border-2 flex items-center justify-center transition-transform pointer-events-none ${
              isInteracting
                ? 'scale-110 border-cyan-400 bg-cyan-950/60 shadow-lg shadow-cyan-500/30'
                : 'border-violet-500 bg-violet-950/50'
            }`}
          >
            {mode === 'move' && <Move className="w-4 h-4 text-violet-300" />}
            {mode === 'rotate' && <RotateCw className="w-4 h-4 text-violet-300" />}
            {mode === 'scale' && <Maximize2 className="w-4 h-4 text-violet-300" />}
            {mode === 'pivot' && <Crosshair className="w-4 h-4 text-violet-300" />}
          </div>

          <span className="absolute bottom-1.5 right-2 text-[10px] text-slate-500 font-mono pointer-events-none">
            DRAG TO ADJUST
          </span>
        </div>
      </div>

      {/* Value Readout & Precision Nudge Controls */}
      <div className="mt-2.5 flex items-center justify-between text-xs font-mono">
        {mode === 'move' && (
          <div className="text-slate-300">
            X: <span className="text-violet-400">{t.position.x}px</span> · Y:{' '}
            <span className="text-violet-400">{t.position.y}px</span>
          </div>
        )}
        {mode === 'rotate' && (
          <div className="text-slate-300">
            Angle: <span className="text-violet-400">{t.rotation}°</span>
          </div>
        )}
        {mode === 'scale' && (
          <div className="text-slate-300">
            Scale: <span className="text-violet-400">{t.scale.x.toFixed(2)}x</span>
          </div>
        )}
        {mode === 'pivot' && (
          <div className="text-slate-300">
            Anchor: ({(t.anchorPoint.x * 100).toFixed(0)}%, {(t.anchorPoint.y * 100).toFixed(0)}%)
          </div>
        )}

        {/* Step buttons */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => nudge(-1, 0)}
            className="p-1 bg-[#161a25] hover:bg-[#202737] rounded text-slate-300"
            title="Nudge Left / Decrease"
          >
            <ArrowLeft className="w-3 h-3" />
          </button>
          <button
            onClick={() => nudge(1, 0)}
            className="p-1 bg-[#161a25] hover:bg-[#202737] rounded text-slate-300"
            title="Nudge Right / Increase"
          >
            <ArrowRight className="w-3 h-3" />
          </button>
          {mode === 'move' && (
            <>
              <button
                onClick={() => nudge(0, -1)}
                className="p-1 bg-[#161a25] hover:bg-[#202737] rounded text-slate-300"
                title="Nudge Up"
              >
                <ArrowUp className="w-3 h-3" />
              </button>
              <button
                onClick={() => nudge(0, 1)}
                className="p-1 bg-[#161a25] hover:bg-[#202737] rounded text-slate-300"
                title="Nudge Down"
              >
                <ArrowDown className="w-3 h-3" />
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
