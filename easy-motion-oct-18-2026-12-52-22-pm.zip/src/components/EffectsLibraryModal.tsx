import React, { useState } from 'react';
import {
  Sparkles,
  Search,
  X,
  Zap,
  Activity,
  Film,
  Tv,
  Layers,
  Palette,
  Check,
} from 'lucide-react';
import { BUILTIN_EFFECTS, EffectDefinition } from '../utils/effectsLibrary';
import { Layer } from '../types/editor';

interface EffectsLibraryModalProps {
  selectedLayer: Layer | null;
  onApplyEffect: (effectDef: EffectDefinition) => void;
  onClose: () => void;
}

export const EffectsLibraryModal: React.FC<EffectsLibraryModalProps> = ({
  selectedLayer,
  onApplyEffect,
  onClose,
}) => {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = [
    'All',
    'Motion & Shake',
    'Glow & Optical',
    'Glitch & Distortion',
    'Color & Film',
    'Stylize & Retro',
  ];

  const filteredEffects = BUILTIN_EFFECTS.filter((eff) => {
    const matchesSearch =
      eff.name.toLowerCase().includes(search.toLowerCase()) ||
      eff.description.toLowerCase().includes(search.toLowerCase());
    const matchesCategory =
      activeCategory === 'All' || eff.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'Motion & Shake':
        return <Activity className="w-4 h-4 text-violet-400" />;
      case 'Glow & Optical':
        return <Sparkles className="w-4 h-4 text-cyan-400" />;
      case 'Glitch & Distortion':
        return <Zap className="w-4 h-4 text-amber-400" />;
      case 'Color & Film':
        return <Film className="w-4 h-4 text-rose-400" />;
      case 'Stylize & Retro':
        return <Tv className="w-4 h-4 text-emerald-400" />;
      default:
        return <Layers className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="bg-[#11141c] border border-[#232938] rounded-xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#202636] bg-[#0e1017]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-violet-950/60 border border-violet-500/30 text-violet-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-tight">
                  Built-in Effects Library
                </h2>
                <span className="text-xs px-2 py-0.5 rounded bg-[#1e2433] text-violet-300 border border-[#2c354b]">
                  {BUILTIN_EFFECTS.length} VFX
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Alight Motion shakes, CapCut glitch, and After Effects optical shaders
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-[#1a1f2c] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Category Filter Bar */}
        <div className="p-4 border-b border-[#1d222f] bg-[#0c0e15] flex flex-col sm:flex-row items-center gap-3">
          {/* Search Input */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search effects..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-[#151924] border border-[#242b3b] rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500"
            />
          </div>

          {/* Categories */}
          <div className="flex items-center gap-1 overflow-x-auto w-full pb-1 sm:pb-0">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                  activeCategory === cat
                    ? 'bg-violet-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#171b26]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Target Layer Indicator */}
        <div className="px-6 py-2 bg-[#141822] border-b border-[#1c2230] text-xs text-slate-400 flex items-center justify-between">
          <span>
            Applying to layer:{' '}
            <strong className="text-white">
              {selectedLayer ? selectedLayer.name : 'No layer selected'}
            </strong>
          </span>
          {!selectedLayer && (
            <span className="text-amber-400">Select a clip first to apply effect</span>
          )}
        </div>

        {/* Effects Grid */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {filteredEffects.map((eff) => {
            const alreadyHasEffect = selectedLayer?.effects.some(
              (e) => e.type === eff.type
            );

            return (
              <div
                key={eff.type}
                className="p-3.5 bg-[#141722] border border-[#222838] hover:border-violet-500/50 rounded-xl transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded bg-[#1c2232]">
                        {getCategoryIcon(eff.category)}
                      </div>
                      <span className="text-sm font-semibold text-white">
                        {eff.name}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-violet-950/60 text-violet-300 border border-violet-500/30">
                      {eff.badge}
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed mt-1">
                    {eff.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#1e2434] flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">
                    Category: <span className="text-slate-300">{eff.category}</span>
                  </span>

                  <button
                    onClick={() => {
                      onApplyEffect(eff);
                      onClose();
                    }}
                    disabled={!selectedLayer}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-violet-600 hover:bg-violet-500 text-white disabled:opacity-40 transition-colors shadow-xs active:scale-95"
                  >
                    {alreadyHasEffect ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Add Another</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Apply Effect</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
