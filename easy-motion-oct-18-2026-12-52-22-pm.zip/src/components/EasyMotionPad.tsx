import React, { useState, useRef } from 'react';
import {
  Move,
  RotateCw,
  Maximize2,
  Crosshair,
  Diamond,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Zap,
} from 'lucide-react';
import { Layer, KeyframableProperty } from '../types/editor';

interface EasyMotionPadProps {
  layer: Layer | null;
  currentTime: number;
  onUpdateTransform: (
    layerId: string,
    transform: Layer['transform']
  ) => void;
  onAddOrRemoveKeyframe: (layerId: string, property: KeyframableProperty) => void;
  onToggleStopwatch: (layerId: string, property: KeyframableProperty) => void;
}

export const EasyMotionPad: React.FC<EasyMotionPadProps> = ({
  layer,
  currentTime,
  onUpdateTransform,
  onAddOrRemoveKeyframe,
  onToggleStopwatch,
}) => {
  const [mode, setMode] = useState<'move' | 'rotate' | 'scale' | 'pivot'>('move');
  const [uniformScale, setUniformScale] = useState(true);
  const padRef = useRef<HTMLDivElement | null>(null);
  const [isInteracting, setIsInteracting] = useState(false);
  const startPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  if (!layer) return null;
  const t = layer.transform;

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsInteracting(true);
    startPosRef.current = { x: e.clientX, y: e.clientY };
    (e.target as Element).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isInteracting) return;
    const dx = e.clientX - startPosRef.current.x;
    const dy = e.clientY - startPosRef.current.y;
    startPosRef.current = { x: e.clientX, y: e.clientY };

    if (mode === 'move') {
      onUpdateTransform(layer.id, {
        ...t,
        position: {
          x: Math.round(t.position.x + dx),
          y: Math.round(t.position.y + dy),
        },
      });
    } else if (mode === 'scale') {
      const scaleDelta = (dx - dy) * 0.005;
      const newScaleX = Math.max(0.1, t.scale.x + scaleDelta);
      const newScaleY = uniformScale ? newScaleX : Math.max(0.1, t.scale.y - dy * 0.005);
      onUpdateTransform(layer.id, {
        ...t,
        scale: { x: newScaleX, y: newScaleY },
      });
    } else if (mode === 'rotate') {
      const rotDelta = dx * 0.6;
      onUpdateTransform(layer.id, {
        ...t,
        rotation: Math.round((t.rotation + rotDelta) % 360),
      });
    } else if (mode === 'pivot') {
      const newAnchorX = Math.max(0, Math.min(1, t.anchorPoint.x + dx * 0.002));
      const newAnchorY = Math.max(0, Math.min(1, t.anchorPoint.y + dy * 0.002));
      onUpdateTransform(layer.id, {
        ...t,
        anchorPoint: { x: newAnchorX, y: newAnchorY },
      });
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsInteracting(false);
    try {
      (e.target as Element).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
  };

  const nudge = (dx: number, dy: number) => {
    if (mode === 'move') {
      onUpdateTransform(layer.id, {
        ...t,
        position: { x: t.position.x + dx, y: t.position.y + dy },
      });
    } else if (mode === 'rotate') {
      onUpdateTransform(layer.id, {
        ...t,
        rotation: Math.round((t.rotation + dx * 15) % 360),
      });
    } else if (mode === 'scale') {
      const delta = dx * 0.1;
      const sx = Math.max(0.1, t.scale.x + delta);
      onUpdateTransform(layer.id, {
        ...t,
        scale: { x: sx, y: uniformScale ? sx : t.scale.y },
      });
    }
  };

  const currentPropertyKey: KeyframableProperty =
    mode === 'move' ? 'position.x' : mode === 'rotate' ? 'rotation' : 'scale.x';

  const hasKf = layer.keyframes.some(
    (k) => k.property === currentPropertyKey && Math.abs(k.time - currentTime) < 0.05
  );

  return (
    <div className="p-3 bg-[#10131d] border border-[#212738] rounded-2xl shadow-xl select-none">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-[#1d2232]">
        <div className="flex items-center gap-1.5">
          <Zap className="w-4 h-4 text-yellow-400" />
          <span className="text-xs font-bold text-white tracking-tight">
            Easy Motion Transform Pad
          </span>
        </div>

        {/* Keyframe Diamond Button */}
        <button
          onClick={() => onAddOrRemoveKeyframe(layer.id, currentPropertyKey)}
          className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-colors ${
            hasKf
              ? 'bg-yellow-400/20 text-yellow-300 border-yellow-400/50'
              : 'bg-[#181d2a] text-slate-400 hover:text-white border-[#273042]'
          }`}
        >
          <Diamond className={`w-3.5 h-3.5 ${hasKf ? 'fill-yellow-400' : 'text-yellow-400'}`} />
          <span>{hasKf ? 'Keyframed' : 'Set Keyframe'}</span>
        </button>
      </div>

      {/* Mode Selector */}
      <div className="grid grid-cols-4 gap-1.5 mt-2.5">
        <button
          onClick={() => setMode('move')}
          className={`py-1.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-colors ${
            mode === 'move'
              ? 'bg-yellow-400 text-slate-950 shadow-xs'
              : 'bg-[#151924] text-slate-400 hover:text-slate-200'
          }`}
        >
          <Move className="w-3.5 h-3.5" />
          <span>Move</span>
        </button>

        <button
          onClick={() => setMode('rotate')}
          className={`py-1.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-colors ${
            mode === 'rotate'
              ? 'bg-yellow-400 text-slate-950 shadow-xs'
              : 'bg-[#151924] text-slate-400 hover:text-slate-200'
          }`}
        >
          <RotateCw className="w-3.5 h-3.5" />
          <span>Rotate</span>
        </button>

        <button
          onClick={() => setMode('scale')}
          className={`py-1.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-colors ${
            mode === 'scale'
              ? 'bg-yellow-400 text-slate-950 shadow-xs'
              : 'bg-[#151924] text-slate-400 hover:text-slate-200'
          }`}
        >
          <Maximize2 className="w-3.5 h-3.5" />
          <span>Scale</span>
        </button>

        <button
          onClick={() => setMode('pivot')}
          className={`py-1.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-colors ${
            mode === 'pivot'
              ? 'bg-yellow-400 text-slate-950 shadow-xs'
              : 'bg-[#151924] text-slate-400 hover:text-slate-200'
          }`}
        >
          <Crosshair className="w-3.5 h-3.5" />
          <span>Pivot</span>
        </button>
      </div>

      {/* 2D Touch Trackpad */}
      <div className="mt-2.5 relative">
        <div
          ref={padRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="h-28 bg-[#0a0c12] border border-[#1d2334] rounded-xl flex items-center justify-center cursor-crosshair touch-none relative overflow-hidden"
        >
          {/* Subtle Grid crosshair */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-full h-[1px] bg-white/5" />
            <div className="h-full w-[1px] bg-white/5 absolute" />
          </div>

          {/* Interactive Thumb Puck */}
          <div
            className={`w-10 h-10 rounded-full border-2 flex items-center justify-center transition-transform pointer-events-none ${
              isInteracting
                ? 'scale-110 border-yellow-400 bg-yellow-400/30 shadow-lg shadow-yellow-400/20'
                : 'border-yellow-400/70 bg-[#161a25]'
            }`}
          >
            {mode === 'move' && <Move className="w-4 h-4 text-yellow-400" />}
            {mode === 'rotate' && <RotateCw className="w-4 h-4 text-yellow-400" />}
            {mode === 'scale' && <Maximize2 className="w-4 h-4 text-yellow-400" />}
            {mode === 'pivot' && <Crosshair className="w-4 h-4 text-yellow-400" />}
          </div>

          <span className="absolute bottom-1.5 right-2 text-[10px] text-slate-600 font-mono pointer-events-none">
            TOUCH & DRAG
          </span>
        </div>
      </div>

      {/* Value Readout & Nudge */}
      <div className="mt-2.5 flex items-center justify-between text-xs font-mono">
        {mode === 'move' && (
          <div className="text-slate-300">
            X: <span className="text-yellow-400">{t.position.x}px</span> · Y:{' '}
            <span className="text-yellow-400">{t.position.y}px</span>
          </div>
        )}
        {mode === 'rotate' && (
          <div className="text-slate-300">
            Angle: <span className="text-yellow-400">{t.rotation}°</span>
          </div>
        )}
        {mode === 'scale' && (
          <div className="text-slate-300">
            Scale: <span className="text-yellow-400">{t.scale.x.toFixed(2)}x</span>
          </div>
        )}
        {mode === 'pivot' && (
          <div className="text-slate-300">
            Anchor: ({(t.anchorPoint.x * 100).toFixed(0)}%, {(t.anchorPoint.y * 100).toFixed(0)}%)
          </div>
        )}

        <div className="flex items-center gap-1">
          <button
            onClick={() => nudge(-1, 0)}
            className="p-1.5 bg-[#161a25] hover:bg-[#202737] rounded-md text-slate-300"
            title="Step Left"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => nudge(1, 0)}
            className="p-1.5 bg-[#161a25] hover:bg-[#202737] rounded-md text-slate-300"
            title="Step Right"
          >
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          {mode === 'move' && (
            <>
              <button
                onClick={() => nudge(0, -1)}
                className="p-1.5 bg-[#161a25] hover:bg-[#202737] rounded-md text-slate-300"
                title="Step Up"
              >
                <ArrowUp className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => nudge(0, 1)}
                className="p-1.5 bg-[#161a25] hover:bg-[#202737] rounded-md text-slate-300"
                title="Step Down"
              >
                <ArrowDown className="w-3.5 h-3.5" />
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
