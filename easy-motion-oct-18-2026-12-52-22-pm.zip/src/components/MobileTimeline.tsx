import React, { useRef, useState } from 'react';
import {
  Scissors,
  Diamond,
  Play,
  Pause,
  Copy,
  Trash2,
  Video,
  Type,
  Square,
  Music,
  Layers,
} from 'lucide-react';
import { Layer, KeyframableProperty } from '../types/editor';

interface MobileTimelineProps {
  layers: Layer[];
  selectedLayerId: string | null;
  selectedKeyframeId: string | null;
  currentTime: number;
  duration: number;
  fps: number;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onSelectLayer: (id: string | null) => void;
  onSelectKeyframe: (kfId: string | null) => void;
  onSeek: (time: number) => void;
  onUpdateLayerTime: (id: string, start: number, duration: number) => void;
  onSplitLayer: (id: string, time: number) => void;
  onDeleteLayer: (id: string) => void;
  onAddOrRemoveKeyframe: (layerId: string, property: KeyframableProperty) => void;
}

export const MobileTimeline: React.FC<MobileTimelineProps> = ({
  layers,
  selectedLayerId,
  selectedKeyframeId,
  currentTime,
  duration,
  fps,
  isPlaying,
  onTogglePlay,
  onSelectLayer,
  onSelectKeyframe,
  onSeek,
  onUpdateLayerTime,
  onSplitLayer,
  onDeleteLayer,
  onAddOrRemoveKeyframe,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const zoom = 55; // Touch-friendly scale: 55px per second
  const selectedLayer = layers.find((l) => l.id === selectedLayerId);

  const [isScrubbing, setIsScrubbing] = useState(false);
  const [draggingClip, setDraggingClip] = useState<{
    layerId: string;
    type: 'move' | 'trim-start' | 'trim-end';
    startX: number;
    origStart: number;
    origDuration: number;
  } | null>(null);

  const handlePointerDownRuler = (e: React.PointerEvent) => {
    setIsScrubbing(true);
    (e.target as Element).setPointerCapture(e.pointerId);
    seekFromX(e.clientX);
  };

  const seekFromX = (clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const scrollLeft = containerRef.current.scrollLeft;
    const clickX = clientX - rect.left + scrollLeft;
    const t = Math.max(0, Math.min(duration, clickX / zoom));
    onSeek(t);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (isScrubbing) {
      seekFromX(e.clientX);
    } else if (draggingClip) {
      const dx = e.clientX - draggingClip.startX;
      const dt = dx / zoom;
      const { layerId, type, origStart, origDuration } = draggingClip;

      if (type === 'move') {
        const newStart = Math.max(0, origStart + dt);
        onUpdateLayerTime(layerId, newStart, origDuration);
      } else if (type === 'trim-start') {
        const newStart = Math.min(
          origStart + origDuration - 0.2,
          Math.max(0, origStart + dt)
        );
        onUpdateLayerTime(layerId, newStart, origDuration - (newStart - origStart));
      } else if (type === 'trim-end') {
        const newDur = Math.max(0.2, origDuration + dt);
        onUpdateLayerTime(layerId, origStart, newDur);
      }
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsScrubbing(false);
    setDraggingClip(null);
    try {
      (e.target as Element).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
  };

  const maxTrack = Math.max(2, ...layers.map((l) => l.trackIndex));
  const tracks = Array.from({ length: maxTrack + 1 }, (_, i) => i);

  // Check if active layer has keyframe at current playhead
  const hasKeyframeAtPlayhead = selectedLayer?.keyframes.some(
    (k) => Math.abs(k.time - currentTime) < 0.08
  );

  return (
    <div
      className="bg-[#0b0c10] border-t border-[#181d28] flex flex-col shrink-0 select-none"
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      {/* Quick Mobile Action Bar (Play, Split, Keyframe, Delete) */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-[#181d28] bg-[#0e1119]">
        {/* Play/Pause Button */}
        <button
          onClick={onTogglePlay}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold text-xs shadow-md transition-all active:scale-95"
        >
          {isPlaying ? (
            <Pause className="w-4 h-4 fill-current" />
          ) : (
            <Play className="w-4 h-4 fill-current" />
          )}
          <span>{isPlaying ? 'Pause' : 'Play'}</span>
        </button>

        {/* Editing Tools */}
        <div className="flex items-center gap-2">
          {/* Split Clip Button */}
          <button
            onClick={() => {
              if (selectedLayer) onSplitLayer(selectedLayer.id, currentTime);
            }}
            disabled={!selectedLayer}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#181d2a] hover:bg-[#22293b] border border-[#262f44] text-xs font-semibold text-slate-200 disabled:opacity-30 transition-colors"
            title="Split Clip at Playhead"
          >
            <Scissors className="w-3.5 h-3.5 text-yellow-400" />
            <span>Split</span>
          </button>

          {/* Add Keyframe Button */}
          <button
            onClick={() => {
              if (selectedLayer)
                onAddOrRemoveKeyframe(selectedLayer.id, 'scale.x');
            }}
            disabled={!selectedLayer}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors disabled:opacity-30 ${
              hasKeyframeAtPlayhead
                ? 'bg-yellow-400/20 text-yellow-300 border-yellow-400/50'
                : 'bg-[#181d2a] hover:bg-[#22293b] border-[#262f44] text-slate-200'
            }`}
            title="Add or Remove Keyframe at Playhead"
          >
            <Diamond className={`w-3.5 h-3.5 ${hasKeyframeAtPlayhead ? 'fill-yellow-400' : 'text-yellow-400'}`} />
            <span>{hasKeyframeAtPlayhead ? 'Keyframed' : 'Keyframe'}</span>
          </button>

          {/* Delete Clip */}
          {selectedLayer && (
            <button
              onClick={() => onDeleteLayer(selectedLayer.id)}
              className="p-1.5 rounded-lg bg-[#181d2a] hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 border border-[#262f44] transition-colors"
              title="Delete Clip"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Scrubbable Multi-Track Clip Area */}
      <div
        ref={containerRef}
        className="h-32 overflow-x-auto overflow-y-hidden relative timeline-grid px-4 py-2"
      >
        <div
          className="relative h-full"
          style={{ width: `${Math.max(800, duration * zoom + 120)}px` }}
          onPointerDown={handlePointerDownRuler}
        >
          {/* Seconds Ticks */}
          {Array.from({ length: Math.ceil(duration) + 1 }, (_, s) => (
            <div
              key={s}
              className="absolute top-0 bottom-0 border-l border-slate-800 text-[9px] font-mono text-slate-500 pl-1 pointer-events-none"
              style={{ left: `${s * zoom}px` }}
            >
              {s}s
            </div>
          ))}

          {/* Track Lanes */}
          <div className="relative pt-4 space-y-2">
            {tracks.map((trackIdx) => {
              const trackLayers = layers.filter((l) => l.trackIndex === trackIdx);

              return (
                <div key={trackIdx} className="h-8 relative">
                  {trackLayers.map((l) => {
                    const isSelected = l.id === selectedLayerId;
                    const leftPx = l.start * zoom;
                    const widthPx = l.duration * zoom;

                    return (
                      <div
                        key={l.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectLayer(l.id);
                        }}
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          onSelectLayer(l.id);
                          setDraggingClip({
                            layerId: l.id,
                            type: 'move',
                            startX: e.clientX,
                            origStart: l.start,
                            origDuration: l.duration,
                          });
                          (e.target as Element).setPointerCapture(e.pointerId);
                        }}
                        className={`absolute top-0 bottom-0 rounded-lg border text-xs flex items-center justify-between px-2 cursor-pointer transition-shadow ${
                          isSelected
                            ? 'bg-yellow-400/30 border-yellow-400 shadow-md shadow-yellow-400/20 text-white'
                            : 'bg-[#151924] border-[#242b3b] text-slate-300 hover:border-slate-400'
                        }`}
                        style={{
                          left: `${leftPx}px`,
                          width: `${widthPx}px`,
                        }}
                      >
                        <span className="text-[11px] font-medium truncate pointer-events-none">
                          {l.name}
                        </span>

                        {/* Trim handles */}
                        <div
                          className="absolute left-0 top-0 bottom-0 w-2 bg-yellow-400/50 hover:bg-yellow-400 rounded-l cursor-ew-resize"
                          onPointerDown={(e) => {
                            e.stopPropagation();
                            setDraggingClip({
                              layerId: l.id,
                              type: 'trim-start',
                              startX: e.clientX,
                              origStart: l.start,
                              origDuration: l.duration,
                            });
                            (e.target as Element).setPointerCapture(e.pointerId);
                          }}
                        />
                        <div
                          className="absolute right-0 top-0 bottom-0 w-2 bg-yellow-400/50 hover:bg-yellow-400 rounded-r cursor-ew-resize"
                          onPointerDown={(e) => {
                            e.stopPropagation();
                            setDraggingClip({
                              layerId: l.id,
                              type: 'trim-end',
                              startX: e.clientX,
                              origStart: l.start,
                              origDuration: l.duration,
                            });
                            (e.target as Element).setPointerCapture(e.pointerId);
                          }}
                        />

                        {/* Keyframe diamonds on clip */}
                        {l.keyframes.map((kf) => {
                          const kfOffsetSec = kf.time - l.start;
                          if (kfOffsetSec < 0 || kfOffsetSec > l.duration)
                            return null;
                          const kfPx = kfOffsetSec * zoom;
                          const isKfSelected = kf.id === selectedKeyframeId;

                          return (
                            <div
                              key={kf.id}
                              onClick={(e) => {
                                e.stopPropagation();
                                onSelectLayer(l.id);
                                onSelectKeyframe(kf.id);
                              }}
                              className={`absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3 h-3 rotate-45 border z-10 cursor-pointer ${
                                isKfSelected
                                  ? 'bg-amber-300 border-white shadow-sm'
                                  : 'bg-yellow-400 border-black shadow-xs'
                              }`}
                              style={{ left: `${kfPx}px` }}
                              title={`${kf.property}: ${kf.value}`}
                            />
                          );
                        })}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>

          {/* Red Playhead Line */}
          <div
            className="absolute top-0 bottom-0 w-[2px] bg-red-500 shadow-md shadow-red-500/50 pointer-events-none z-20"
            style={{ left: `${currentTime * zoom}px` }}
          >
            <div className="w-3.5 h-3.5 bg-red-500 rotate-45 -translate-x-1.5 -translate-y-1.5 shadow-md" />
          </div>
        </div>
      </div>
    </div>
  );
};
