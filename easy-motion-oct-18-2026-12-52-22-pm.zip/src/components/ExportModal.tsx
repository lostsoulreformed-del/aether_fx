import React, { useState, useEffect } from 'react';
import {
  Download,
  Sparkles,
  Check,
  X,
  Cpu,
  Film,
  Zap,
} from 'lucide-react';
import { ProjectSettings, TopazSettings } from '../types/editor';

interface ExportModalProps {
  project: ProjectSettings;
  topazSettings: TopazSettings;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  project,
  topazSettings,
  onClose,
}) => {
  const [resolution, setResolution] = useState<'1080p' | '2k' | '4k'>('4k');
  const [fps, setFps] = useState<number>(60);
  const [format, setFormat] = useState<'webm' | 'mp4'>('webm');
  const [isExporting, setIsExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isComplete, setIsComplete] = useState(false);

  // Simulated high-fidelity rendering pipeline
  useEffect(() => {
    let timer: number;
    if (isExporting && progress < 100) {
      timer = window.setTimeout(() => {
        setProgress((prev) => {
          const next = prev + 4;
          if (next >= 100) {
            setIsComplete(true);
            setIsExporting(false);
            return 100;
          }
          return next;
        });
      }, 120);
    }
    return () => clearTimeout(timer);
  }, [isExporting, progress]);

  const handleStartRender = () => {
    setIsExporting(true);
    setProgress(0);
    setIsComplete(false);
  };

  const handleDownload = () => {
    // Generate sample blob download
    const blob = new Blob(
      [`Easy Motion 4K Rendered Master\nResolution: ${resolution}\nTopaz Model: ${topazSettings.model}`],
      { type: 'text/plain' }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `EasyMotion_${project.title.replace(/\s+/g, '_')}_${resolution}_${fps}fps.webm`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="bg-[#11141c] border border-[#232938] rounded-xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#202636] bg-[#0e1017]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-violet-950/60 border border-violet-500/30 text-violet-400">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-tight">
                Export Master Video
              </h2>
              <span className="text-xs text-slate-400">
                Topaz 4K Neural Super-Resolution Master
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-[#1a1f2c]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Configuration Body */}
        <div className="p-6 space-y-4">
          {/* Resolution */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">
              Target Resolution
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setResolution('1080p')}
                className={`py-2 px-3 rounded-lg border text-xs font-mono font-medium transition-colors ${
                  resolution === '1080p'
                    ? 'bg-violet-600 border-violet-500 text-white'
                    : 'bg-[#151924] border-[#22293b] text-slate-400 hover:text-slate-200'
                }`}
              >
                1080p FHD
              </button>
              <button
                onClick={() => setResolution('2k')}
                className={`py-2 px-3 rounded-lg border text-xs font-mono font-medium transition-colors ${
                  resolution === '2k'
                    ? 'bg-violet-600 border-violet-500 text-white'
                    : 'bg-[#151924] border-[#22293b] text-slate-400 hover:text-slate-200'
                }`}
              >
                2K QHD
              </button>
              <button
                onClick={() => setResolution('4k')}
                className={`py-2 px-3 rounded-lg border text-xs font-mono font-medium transition-colors ${
                  resolution === '4k'
                    ? 'bg-cyan-500 border-cyan-400 text-slate-950 font-bold'
                    : 'bg-[#151924] border-[#22293b] text-slate-400 hover:text-slate-200'
                }`}
              >
                4K UHD (Master)
              </button>
            </div>
          </div>

          {/* Framerate & Format */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                Framerate (FPS)
              </label>
              <select
                value={fps}
                onChange={(e) => setFps(Number(e.target.value))}
                className="w-full bg-[#151924] border border-[#22293b] rounded-lg px-3 py-2 text-xs text-white focus:outline-none"
              >
                <option value={30}>30 FPS Standard</option>
                <option value={60}>60 FPS Chronos Smooth</option>
                <option value={120}>120 FPS High Speed</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                Format
              </label>
              <select
                value={format}
                onChange={(e) => setFormat(e.target.value as 'webm' | 'mp4')}
                className="w-full bg-[#151924] border border-[#22293b] rounded-lg px-3 py-2 text-xs text-white focus:outline-none"
              >
                <option value="webm">WebM VP9 (Lossless)</option>
                <option value="mp4">MP4 H.264 (Universal)</option>
              </select>
            </div>
          </div>

          {/* Topaz AI Status Banner */}
          <div className="p-3 bg-cyan-950/30 border border-cyan-500/30 rounded-lg flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <div className="text-xs">
                <span className="font-semibold text-cyan-300">
                  Topaz {topazSettings.model.toUpperCase()} Engine
                </span>
                <div className="text-[10px] text-slate-400">
                  {topazSettings.sharpen}% Crisp · {topazSettings.recoverDetails}% Iris Detail · Bilateral Clean
                </div>
              </div>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300">
              Active
            </span>
          </div>

          {/* Render Progress */}
          {(isExporting || isComplete) && (
            <div className="p-3 bg-[#131722] border border-[#22293b] rounded-lg space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300">
                  {isComplete ? 'Render Finished!' : 'Rendering Neural Shaders...'}
                </span>
                <span className="font-mono text-cyan-400">{progress}%</span>
              </div>
              <div className="w-full h-2 bg-[#1b202c] rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-violet-600 to-cyan-400 transition-all duration-150"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-[#1e2434] bg-[#0e1017] flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs font-medium text-slate-400 hover:text-white transition-colors"
          >
            Cancel
          </button>

          {isComplete ? (
            <button
              onClick={handleDownload}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md transition-colors"
            >
              <Check className="w-4 h-4" />
              <span>Download 4K Video</span>
            </button>
          ) : (
            <button
              onClick={handleStartRender}
              disabled={isExporting}
              className="flex items-center gap-2 px-5 py-2 rounded-lg text-xs font-semibold bg-gradient-to-r from-violet-600 via-indigo-600 to-cyan-600 hover:opacity-95 text-white shadow-md transition-all disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{isExporting ? 'Processing 4K...' : 'Start 4K Render'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
