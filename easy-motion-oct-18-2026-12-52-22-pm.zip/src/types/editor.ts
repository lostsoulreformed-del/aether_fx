export type LayerType = 'video' | 'image' | 'text' | 'shape' | 'audio' | 'adjustment' | 'null' | 'group';

export type BlendMode =
  | 'normal'
  | 'screen'
  | 'multiply'
  | 'add'
  | 'color-dodge'
  | 'overlay'
  | 'soft-light'
  | 'difference'
  | 'exclusion'
  | 'luminosity';

export type TemporalInterpolation = 'bezier' | 'linear' | 'hold';

export type BezierCurveType =
  | 'linear'
  | 'easeIn'
  | 'easeOut'
  | 'easeInOut'
  | 'bounce'
  | 'velocityPop'
  | 'custom';

export interface BezierHandle {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

export type KeyframableProperty =
  | 'position.x'
  | 'position.y'
  | 'scale.x'
  | 'scale.y'
  | 'rotation'
  | 'opacity'
  | 'blur'
  | 'glow'
  | 'saturation'
  | 'cornerRadius'
  | 'borderWidth';

export interface Keyframe {
  id: string;
  time: number; // in seconds
  property: KeyframableProperty;
  value: number;
  interpolation: TemporalInterpolation; // 'bezier' | 'linear' | 'hold'
  curve: BezierCurveType;
  bezierHandle?: BezierHandle;
}

export type EffectType =
  | 'cameraShake'
  | 'deepGlow'
  | 'chromaticAberration'
  | 'rgbGlitch'
  | 'filmBurn'
  | 'vignette'
  | 'colorGrade'
  | 'lensDistort'
  | 'neonEdges'
  | 'halftone'
  // Alight Motion Signatures
  | 'amTiles'
  | 'amOscillate'
  | 'amWaveWarp'
  | 'amPinch'
  | 'amFlip3D';

export interface EffectItem {
  id: string;
  type: EffectType;
  name: string;
  enabled: boolean;
  params: Record<string, number | string | boolean>;
}

export interface SpeedRampPoint {
  timeRatio: number;
  speedMultiplier: number;
}

export interface SpeedRamp {
  enabled: boolean;
  preset: 'custom' | 'hero' | 'montage' | 'bullet' | 'jumpCut';
  points: SpeedRampPoint[];
}

export interface FillGradient {
  enabled: boolean;
  type: 'linear' | 'radial';
  color1: string;
  color2: string;
  angle: number; // degrees
}

export interface LayerBorder {
  enabled: boolean;
  color: string;
  width: number;
  style: 'solid' | 'dashed';
}

export interface LayerShadow {
  enabled: boolean;
  color: string;
  offsetX: number;
  offsetY: number;
  blur: number;
}

export interface Layer {
  id: string;
  name: string;
  type: LayerType;
  trackIndex: number;
  start: number; // seconds
  duration: number; // seconds
  sourceUrl?: string;
  color?: string;
  // Alight Motion Vector Shape Properties
  shapeType?: 'rectangle' | 'circle' | 'triangle' | 'star' | 'heart' | 'arrow';
  cornerRadius?: number; // for rounded rectangles
  starPoints?: number; // e.g. 5, 6, 8 points
  // Typography
  text?: string;
  fontSize?: number;
  fontFamily?: string;
  letterSpacing?: number;
  // Fill, Border & Shadow (AM Styling)
  fillColor?: string;
  gradient?: FillGradient;
  border?: LayerBorder;
  shadow?: LayerShadow;
  // Text Stroke
  strokeColor?: string;
  strokeWidth?: number;
  // Hierarchy
  parentId?: string | null; // After Effects & AM Parenting
  maskWithAbove?: boolean; // Alight Motion Group & Mask
  blendMode: BlendMode;
  opacity: number; // 0-100
  visible: boolean;
  locked: boolean;
  motionBlur: boolean; // Shutter angle blur
  // Transform Matrix
  transform: {
    position: { x: number; y: number };
    scale: { x: number; y: number };
    rotation: number; // degrees
    anchorPoint: { x: number; y: number };
    skewX?: number; // Skew / Shear
    skewY?: number;
  };
  blur: number;
  glow: number;
  saturation: number;
  // Active Keyframe Stopwatches
  activeStopwatches: Partial<Record<KeyframableProperty, boolean>>;
  keyframes: Keyframe[];
  effects: EffectItem[];
  speedRamp?: SpeedRamp;
}

export type TopazModel =
  | 'proteus-v4'
  | 'gaia-hq'
  | 'iris-face'
  | 'chronos-60fps'
  | 'dione-dehalo';

export interface TopazSettings {
  enabled: boolean;
  splitView: boolean;
  splitPosition: number;
  model: TopazModel;
  upscaleTarget: '1080p' | '2k' | '4k' | '8k';
  upscaleFactor: number;
  sharpen: number;
  recoverDetails: number;
  deNoise: number;
  chromaDeNoise: number;
  edgePreserveThreshold: number;
  artifactRemoval: number;
  deHalo: number;
  antiAliasing: number;
  grainAmount: number;
  opticalFlowSmooth: boolean;
}

export interface ProjectSettings {
  title: string;
  width: number;
  height: number;
  aspectRatio: '16:9' | '9:16' | '1:1';
  fps: number;
  duration: number;
}
