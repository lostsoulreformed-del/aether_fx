import React, { useState, useEffect, useRef, useCallback } from 'react';
import { MobileTopBar } from './components/MobileTopBar';
import { MobileBottomNav, MobileTab } from './components/MobileBottomNav';
import { MobileTimeline } from './components/MobileTimeline';
import { Viewport } from './components/Viewport';
import { EasyMotionPad } from './components/EasyMotionPad';
import { GraphEditor } from './components/GraphEditor';
import { TopazLaboratory } from './components/TopazLaboratory';
import { EffectsLibraryModal } from './components/EffectsLibraryModal';
import { MediaLibrary } from './components/MediaLibrary';
import { ExportModal } from './components/ExportModal';
import { ApkDownloadModal } from './components/ApkDownloadModal';
import {
  Layer,
  ProjectSettings,
  TopazSettings,
  Keyframe,
  KeyframableProperty,
  TemporalInterpolation,
  BezierCurveType,
  BezierHandle,
} from './types/editor';
import {
  INITIAL_LAYERS,
  TOPAZ_DEFAULT_SETTINGS,
} from './utils/presets';
import { EffectDefinition, BUILTIN_EFFECTS } from './utils/effectsLibrary';
import { audioEngine } from './utils/audioEngine';
import { X, Sliders, ChevronDown } from 'lucide-react';

export default function App() {
  // Project settings
  const [project, setProject] = useState<ProjectSettings>({
    title: 'Easy Motion Project',
    width: 1080,
    height: 1920,
    aspectRatio: '9:16', // Default mobile vertical format (Reels/Shorts/TikTok)
    fps: 30,
    duration: 10,
  });

  // Editor State
  const [layers, setLayers] = useState<Layer[]>(INITIAL_LAYERS);
  const [selectedLayerId, setSelectedLayerId] = useState<string | null>('layer-title-text');
  const [selectedKeyframeId, setSelectedKeyframeId] = useState<string | null>('kf-txt-scale1');
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [topazSettings, setTopazSettings] = useState<TopazSettings>(TOPAZ_DEFAULT_SETTINGS);

  // Active Bottom Drawer state (one-at-a-time, clean mobile navigation!)
  const [activeTab, setActiveTab] = useState<MobileTab>('none');

  // Modals
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isApkOpen, setIsApkOpen] = useState(false);

  // Animation frame loop
  const animFrameRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(0);

  const selectedLayer = layers.find((l) => l.id === selectedLayerId) || null;
  const selectedKeyframe =
    selectedLayer?.keyframes.find((k) => k.id === selectedKeyframeId) || null;

  // Toggle Playback
  const handleTogglePlay = useCallback(() => {
    setIsPlaying((prev) => {
      const next = !prev;
      if (next) {
        audioEngine.play(currentTime, 135);
        lastTimeRef.current = performance.now();
      } else {
        audioEngine.pause();
      }
      return next;
    });
  }, [currentTime]);

  const handleSeek = useCallback(
    (newTime: number) => {
      const clamped = Math.max(0, Math.min(project.duration, newTime));
      setCurrentTime(clamped);
      audioEngine.updateTime(clamped, 135);
    },
    [project.duration]
  );

  useEffect(() => {
    const loop = (timestamp: number) => {
      if (isPlaying) {
        const deltaSec = (timestamp - lastTimeRef.current) / 1000;
        lastTimeRef.current = timestamp;

        setCurrentTime((prev) => {
          const next = prev + deltaSec;
          if (next >= project.duration) {
            setIsPlaying(false);
            audioEngine.pause();
            return 0;
          }
          audioEngine.updateTime(next, 135);
          return next;
        });
        animFrameRef.current = requestAnimationFrame(loop);
      }
    };

    if (isPlaying) {
      lastTimeRef.current = performance.now();
      animFrameRef.current = requestAnimationFrame(loop);
    } else {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    }

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isPlaying, project.duration]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement ||
        e.target instanceof HTMLSelectElement
      ) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        handleTogglePlay();
      } else if (e.code === 'KeyS' || (e.ctrlKey && e.code === 'KeyB')) {
        e.preventDefault();
        if (selectedLayerId) {
          handleSplitLayer(selectedLayerId, currentTime);
        }
      } else if (e.code === 'Delete' || e.code === 'Backspace') {
        if (selectedLayerId) {
          e.preventDefault();
          handleDeleteLayer(selectedLayerId);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleTogglePlay, selectedLayerId, currentTime]);

  // Layer Update
  const handleUpdateLayer = (layerId: string, updates: Partial<Layer>) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === layerId ? { ...l, ...updates } : l))
    );
  };

  // Direct transform update
  const handleUpdateLayerTransform = (
    layerId: string,
    transform: Layer['transform']
  ) => {
    setLayers((prev) =>
      prev.map((l) => {
        if (l.id !== layerId) return l;

        let updatedKeyframes = [...l.keyframes];
        const recordAutoKf = (prop: KeyframableProperty, val: number) => {
          if (l.activeStopwatches[prop]) {
            const existingIdx = updatedKeyframes.findIndex(
              (k) => k.property === prop && Math.abs(k.time - currentTime) < 0.05
            );
            if (existingIdx >= 0) {
              updatedKeyframes[existingIdx] = {
                ...updatedKeyframes[existingIdx],
                value: val,
              };
            } else {
              updatedKeyframes.push({
                id: `kf-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
                time: currentTime,
                property: prop,
                value: val,
                interpolation: 'bezier',
                curve: 'easeInOut',
              });
            }
          }
        };

        recordAutoKf('position.x', transform.position.x);
        recordAutoKf('position.y', transform.position.y);
        recordAutoKf('scale.x', transform.scale.x);
        recordAutoKf('scale.y', transform.scale.y);
        recordAutoKf('rotation', transform.rotation);

        return { ...l, transform, keyframes: updatedKeyframes };
      })
    );
  };

  // Add or remove keyframe diamond
  const handleAddOrRemoveKeyframe = (
    layerId: string,
    property: KeyframableProperty
  ) => {
    setLayers((prev) =>
      prev.map((l) => {
        if (l.id !== layerId) return l;
        const existingIdx = l.keyframes.findIndex(
          (k) => k.property === property && Math.abs(k.time - currentTime) < 0.05
        );

        if (existingIdx >= 0) {
          const updated = l.keyframes.filter((_, idx) => idx !== existingIdx);
          return { ...l, keyframes: updated };
        } else {
          let val = 0;
          if (property === 'position.x') val = l.transform.position.x;
          else if (property === 'position.y') val = l.transform.position.y;
          else if (property === 'scale.x') val = l.transform.scale.x;
          else if (property === 'scale.y') val = l.transform.scale.y;
          else if (property === 'rotation') val = l.transform.rotation;
          else if (property === 'opacity') val = l.opacity;
          else if (property === 'blur') val = l.blur;

          const newKf: Keyframe = {
            id: `kf-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            time: currentTime,
            property,
            value: val,
            interpolation: 'bezier',
            curve: 'easeInOut',
          };
          return {
            ...l,
            activeStopwatches: { ...l.activeStopwatches, [property]: true },
            keyframes: [...l.keyframes, newKf],
          };
        }
      })
    );
  };

  // Update keyframe curve from Graph Editor
  const handleUpdateKeyframeCurve = (
    layerId: string,
    keyframeId: string,
    curve: BezierCurveType,
    handle: BezierHandle
  ) => {
    setLayers((prev) =>
      prev.map((l) =>
        l.id === layerId
          ? {
              ...l,
              keyframes: l.keyframes.map((k) =>
                k.id === keyframeId
                  ? {
                      ...k,
                      interpolation: 'bezier',
                      curve,
                      bezierHandle: handle,
                    }
                  : k
              ),
            }
          : l
      )
    );
  };

  // Split clip
  const handleSplitLayer = (layerId: string, splitTime: number) => {
    const target = layers.find((l) => l.id === layerId);
    if (!target) return;
    if (splitTime <= target.start || splitTime >= target.start + target.duration) {
      return;
    }

    const firstHalfDuration = splitTime - target.start;
    const secondHalfDuration = target.duration - firstHalfDuration;

    const firstHalf: Layer = {
      ...target,
      duration: firstHalfDuration,
      keyframes: target.keyframes.filter((k) => k.time < splitTime),
    };

    const secondHalf: Layer = {
      ...target,
      id: `layer-${Date.now()}`,
      name: `${target.name} (Split)`,
      start: splitTime,
      duration: secondHalfDuration,
      keyframes: target.keyframes.filter((k) => k.time >= splitTime),
    };

    setLayers((prev) =>
      prev.flatMap((l) => (l.id === layerId ? [firstHalf, secondHalf] : [l]))
    );
    setSelectedLayerId(secondHalf.id);
  };

  // Delete clip
  const handleDeleteLayer = (layerId: string) => {
    setLayers((prev) => prev.filter((l) => l.id !== layerId));
    setSelectedLayerId(null);
  };

  // Apply effect
  const handleApplyEffect = (def: EffectDefinition) => {
    if (!selectedLayerId) return;
    const newEffect = {
      id: `eff-${Date.now()}`,
      type: def.type,
      name: def.name,
      enabled: true,
      params: { ...def.defaultParams },
    };

    setLayers((prev) =>
      prev.map((l) =>
        l.id === selectedLayerId
          ? { ...l, effects: [...l.effects, newEffect] }
          : l
      )
    );
  };

  // Add layer
  const handleAddLayer = (partial: Partial<Layer>) => {
    const newLayer: Layer = {
      id: `layer-${Date.now()}`,
      name: partial.name || 'New Layer',
      type: partial.type || 'image',
      trackIndex: layers.length,
      start: currentTime,
      duration: partial.duration || 5,
      sourceUrl: partial.sourceUrl,
      text: partial.text,
      fontSize: partial.fontSize || 56,
      fillColor: partial.fillColor || '#ffffff',
      strokeColor: partial.strokeColor || '#facc15',
      strokeWidth: partial.strokeWidth || 0,
      shapeType: partial.shapeType || 'rectangle',
      blendMode: 'normal',
      opacity: 100,
      visible: true,
      locked: false,
      motionBlur: true,
      transform: {
        position: { x: 0, y: 0 },
        scale: { x: 1, y: 1 },
        rotation: 0,
        anchorPoint: { x: 0.5, y: 0.5 },
      },
      blur: 0,
      glow: 0,
      saturation: 100,
      activeStopwatches: {},
      keyframes: [],
      effects: [],
    };

    setLayers((prev) => [...prev, newLayer]);
    setSelectedLayerId(newLayer.id);
    setActiveTab('none');
  };

  // Reset Demo Scene
  const handleResetDemo = () => {
    setLayers(INITIAL_LAYERS);
    setSelectedLayerId('layer-title-text');
    setCurrentTime(0);
    setIsPlaying(false);
    audioEngine.pause();
    setTopazSettings(TOPAZ_DEFAULT_SETTINGS);
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#07090e] text-[#e2e8f0] select-none font-sans">
      {/* 1. Mobile Top Bar (Logo, Aspect Ratio Switcher, Direct APK Download) */}
      <MobileTopBar
        aspectRatio={project.aspectRatio}
        onToggleAspectRatio={() => {
          setProject((prev) => ({
            ...prev,
            aspectRatio: prev.aspectRatio === '9:16' ? '16:9' : '9:16',
          }));
        }}
        onOpenApkModal={() => setIsApkOpen(true)}
        onOpenExportModal={() => setIsExportOpen(true)}
        onResetDemo={handleResetDemo}
        currentTime={currentTime}
      />

      {/* 2. Main Hero Video Canvas Viewport */}
      <div className="flex-1 relative flex items-center justify-center min-h-0 bg-[#050609] overflow-hidden">
        <Viewport
          project={project}
          layers={layers}
          selectedLayerId={selectedLayerId}
          currentTime={currentTime}
          isPlaying={isPlaying}
          onTogglePlay={handleTogglePlay}
          onSeek={handleSeek}
          topazSettings={topazSettings}
          onUpdateLayerTransform={handleUpdateLayerTransform}
          onUpdateTopazSettings={(newSet) =>
            setTopazSettings((prev) => ({ ...prev, ...newSet }))
          }
        />
      </div>

      {/* 3. Streamlined Mobile Timeline (Split, Keyframes, Dragging) */}
      <MobileTimeline
        layers={layers}
        selectedLayerId={selectedLayerId}
        selectedKeyframeId={selectedKeyframeId}
        currentTime={currentTime}
        duration={project.duration}
        fps={project.fps}
        isPlaying={isPlaying}
        onTogglePlay={handleTogglePlay}
        onSelectLayer={(id) => {
          setSelectedLayerId(id);
          setSelectedKeyframeId(null);
        }}
        onSelectKeyframe={(kfId) => {
          setSelectedKeyframeId(kfId);
          if (kfId) setActiveTab('curves');
        }}
        onSeek={handleSeek}
        onUpdateLayerTime={(id, start, dur) =>
          handleUpdateLayer(id, { start, duration: dur })
        }
        onSplitLayer={handleSplitLayer}
        onDeleteLayer={handleDeleteLayer}
        onAddOrRemoveKeyframe={(layerId, prop) =>
          handleAddOrRemoveKeyframe(layerId, prop)
        }
      />

      {/* 4. Thumb-Friendly Bottom Navigation Dock */}
      <MobileBottomNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        hasSelectedLayer={!!selectedLayer}
        topazEnabled={topazSettings.enabled}
      />

      {/* ================================================================ */}
      {/* CONTEXTUAL SLIDE-UP DRAWERS (Clean, Uncluttered Mobile Sheets)   */}
      {/* ================================================================ */}

      {/* DRAWER 1: Transform Pad & Sliders */}
      {activeTab === 'transform' && selectedLayer && (
        <div className="fixed inset-x-0 bottom-16 z-40 bg-[#0e111a] border-t border-[#232a3c] rounded-t-3xl shadow-2xl p-4 max-h-[60vh] overflow-y-auto">
          <div className="flex items-center justify-between pb-2 border-b border-[#1c2232] mb-3">
            <span className="text-xs font-bold text-white">
              Edit Transform · {selectedLayer.name}
            </span>
            <button
              onClick={() => setActiveTab('none')}
              className="p-1 rounded-lg text-slate-400 hover:text-white"
            >
              <ChevronDown className="w-5 h-5" />
            </button>
          </div>
          <EasyMotionPad
            layer={selectedLayer}
            currentTime={currentTime}
            onUpdateTransform={handleUpdateLayerTransform}
            onAddOrRemoveKeyframe={handleAddOrRemoveKeyframe}
            onToggleStopwatch={(id, prop) => handleAddOrRemoveKeyframe(id, prop)}
          />
        </div>
      )}

      {/* DRAWER 2: Easy Motion Curves */}
      {activeTab === 'curves' && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full max-w-xl">
            <GraphEditor
              selectedLayer={selectedLayer}
              selectedKeyframe={selectedKeyframe}
              onUpdateKeyframeCurve={handleUpdateKeyframeCurve}
              onClose={() => setActiveTab('none')}
            />
          </div>
        </div>
      )}

      {/* DRAWER 3: Built-in Effects Library */}
      {activeTab === 'effects' && (
        <EffectsLibraryModal
          selectedLayer={selectedLayer}
          onApplyEffect={handleApplyEffect}
          onClose={() => setActiveTab('none')}
        />
      )}

      {/* DRAWER 4: Topaz AI Laboratory */}
      {activeTab === 'topaz' && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full max-w-2xl max-h-[85vh] overflow-y-auto">
            <TopazLaboratory
              settings={topazSettings}
              onUpdateSettings={(newSet) =>
                setTopazSettings((prev) => ({ ...prev, ...newSet }))
              }
              onClose={() => setActiveTab('none')}
            />
          </div>
        </div>
      )}

      {/* DRAWER 5: Add Media / Clips */}
      {activeTab === 'add' && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full max-w-lg">
            <MediaLibrary
              onAddLayer={handleAddLayer}
              onClose={() => setActiveTab('none')}
            />
          </div>
        </div>
      )}

      {/* Export Modal */}
      {isExportOpen && (
        <ExportModal
          project={project}
          topazSettings={topazSettings}
          onClose={() => setIsExportOpen(false)}
        />
      )}

      {/* Direct APK Download Modal */}
      {isApkOpen && <ApkDownloadModal onClose={() => setIsApkOpen(false)} />}
    </div>
  );
}
