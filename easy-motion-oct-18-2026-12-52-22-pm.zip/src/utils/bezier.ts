import { BezierCurveType, BezierHandle, TemporalInterpolation } from '../types/editor';

export const CURVE_PRESETS: Record<BezierCurveType, BezierHandle> = {
  linear: { x1: 0.0, y1: 0.0, x2: 1.0, y2: 1.0 },
  easeIn: { x1: 0.42, y1: 0.0, x2: 1.0, y2: 1.0 },
  easeOut: { x1: 0.0, y1: 0.0, x2: 0.58, y2: 1.0 },
  easeInOut: { x1: 0.42, y1: 0.0, x2: 0.58, y2: 1.0 },
  velocityPop: { x1: 0.1, y1: 0.9, x2: 0.2, y2: 1.0 }, // CapCut / AM punchy velocity
  bounce: { x1: 0.175, y1: 0.885, x2: 0.32, y2: 1.275 }, // Overshoot / AM spring
  custom: { x1: 0.25, y1: 0.1, x2: 0.25, y2: 1.0 },
};

/**
 * Solves cubic bezier for a given t [0, 1] using Newton-Raphson approximation
 */
export function solveCubicBezier(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  t: number
): number {
  if (t <= 0) return 0;
  if (t >= 1) return 1;

  // Newton-Raphson to find u corresponding to x(u) = t
  let u = t;
  for (let i = 0; i < 8; i++) {
    const currentX =
      3 * (1 - u) * (1 - u) * u * x1 + 3 * (1 - u) * u * u * x2 + u * u * u;
    const dx =
      3 * (1 - u) * (1 - u) * x1 +
      6 * (1 - u) * u * (x2 - x1) +
      3 * u * u * (1 - x2);
    if (Math.abs(currentX - t) < 0.001 || Math.abs(dx) < 1e-6) break;
    u -= (currentX - t) / dx;
    u = Math.max(0, Math.min(1, u));
  }

  // Calculate y(u)
  const y =
    3 * (1 - u) * (1 - u) * u * y1 + 3 * (1 - u) * u * u * y2 + u * u * u;
  return y;
}

/**
 * Interpolates between two keyframe values using their specified temporal interpolation
 * (hold, linear, or bezier with custom easing curves)
 */
export function interpolateKeyframes(
  t: number, // current time
  k1Time: number,
  k1Val: number,
  k2Time: number,
  k2Val: number,
  interpolation: TemporalInterpolation = 'bezier',
  curve: BezierCurveType = 'easeInOut',
  customHandle?: BezierHandle
): number {
  if (t <= k1Time) return k1Val;
  if (t >= k2Time) return k2Val;
  if (k2Time === k1Time) return k1Val;

  // 1. Hold interpolation: value remains constant until the exact moment of the next keyframe
  if (interpolation === 'hold') {
    return k1Val;
  }

  const progress = (t - k1Time) / (k2Time - k1Time);

  // 2. Linear temporal interpolation
  if (interpolation === 'linear') {
    return k1Val + (k2Val - k1Val) * progress;
  }

  // 3. Bezier temporal interpolation
  const handle =
    curve === 'custom' && customHandle
      ? customHandle
      : CURVE_PRESETS[curve] || CURVE_PRESETS.easeInOut;

  const easedProgress = solveCubicBezier(
    handle.x1,
    handle.y1,
    handle.x2,
    handle.y2,
    progress
  );

  return k1Val + (k2Val - k1Val) * easedProgress;
}
