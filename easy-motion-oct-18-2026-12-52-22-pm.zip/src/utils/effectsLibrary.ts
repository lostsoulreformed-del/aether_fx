import { EffectType } from '../types/editor';

export interface EffectDefinition {
  type: EffectType;
  name: string;
  category: 'Easy Motion Signatures' | 'Motion & Velocity' | 'Optical & Glow' | 'Glitch & Distortion' | 'Color & Cinema' | 'Stylize & Graphic';
  description: string;
  badge: string;
  defaultParams: Record<string, number | string | boolean>;
  paramControls: Array<{
    key: string;
    label: string;
    type: 'slider' | 'select' | 'boolean';
    min?: number;
    max?: number;
    step?: number;
    options?: string[];
  }>;
}

export const BUILTIN_EFFECTS: EffectDefinition[] = [
  // Easy Motion Signatures
  {
    type: 'amTiles',
    name: 'Easy Motion Tiles & Mirror',
    category: 'Easy Motion Signatures',
    description: 'Easy Motion multi-tile repeat with edge mirror reflection for seamless velocity zoom transitions.',
    badge: 'Easy Motion Signature',
    defaultParams: {
      count: 3,
      mirror: true,
      scale: 1.0,
    },
    paramControls: [
      { key: 'count', label: 'Tile Repeats', type: 'slider', min: 1, max: 5, step: 1 },
      { key: 'mirror', label: 'Mirror Edge Reflection', type: 'boolean' },
    ],
  },
  {
    type: 'amOscillate',
    name: 'Easy Motion Oscillate',
    category: 'Easy Motion Signatures',
    description: 'Easy Motion harmonic oscillation along vector angles for rhythmic beat shakes.',
    badge: 'Easy Motion Signature',
    defaultParams: {
      angle: 45,
      frequency: 8,
      magnitude: 14,
    },
    paramControls: [
      { key: 'angle', label: 'Oscillation Angle (°)', type: 'slider', min: 0, max: 360, step: 5 },
      { key: 'frequency', label: 'Frequency (Hz)', type: 'slider', min: 1, max: 25, step: 1 },
      { key: 'magnitude', label: 'Magnitude (Px)', type: 'slider', min: 1, max: 40, step: 1 },
    ],
  },
  {
    type: 'amWaveWarp',
    name: 'Easy Motion Wave Warp',
    category: 'Easy Motion Signatures',
    description: 'Easy Motion sine wave surface displacement with dynamic wavelength and phase velocity.',
    badge: 'Easy Motion Signature',
    defaultParams: {
      amplitude: 12,
      wavelength: 40,
      speed: 2.0,
    },
    paramControls: [
      { key: 'amplitude', label: 'Wave Height', type: 'slider', min: 2, max: 40, step: 1 },
      { key: 'wavelength', label: 'Wavelength', type: 'slider', min: 10, max: 100, step: 2 },
    ],
  },
  {
    type: 'amFlip3D',
    name: 'Easy Motion 3D Layer Flip',
    category: 'Easy Motion Signatures',
    description: 'Easy Motion 3D card perspective rotations along X and Y axes.',
    badge: 'Easy Motion 3D',
    defaultParams: {
      angleX: 0,
      angleY: 25,
      depth: 30,
    },
    paramControls: [
      { key: 'angleX', label: 'Tilt X (°)', type: 'slider', min: -80, max: 80, step: 2 },
      { key: 'angleY', label: 'Flip Y (°)', type: 'slider', min: -80, max: 80, step: 2 },
    ],
  },
  // Motion & Velocity
  {
    type: 'cameraShake',
    name: 'Easy Motion Camera Shake',
    category: 'Motion & Velocity',
    description: 'Smooth high-frequency organic tremor and rotational velocity shake.',
    badge: 'Easy Motion Shake',
    defaultParams: {
      frequency: 6.0,
      amplitude: 8.0,
      speed: 1.2,
    },
    paramControls: [
      { key: 'frequency', label: 'Frequency (Speed)', type: 'slider', min: 1, max: 20, step: 0.5 },
      { key: 'amplitude', label: 'Amplitude (Intensity)', type: 'slider', min: 1, max: 30, step: 1 },
      { key: 'speed', label: 'Velocity Rate', type: 'slider', min: 0.2, max: 3.0, step: 0.1 },
    ],
  },
  // Optical & Glow
  {
    type: 'deepGlow',
    name: 'Easy Motion Deep Optical Bloom',
    category: 'Optical & Glow',
    description: 'High-dynamic-range optical diffusion bloom replicating anamorphic cine lenses.',
    badge: 'Easy Motion Pro',
    defaultParams: {
      intensity: 55,
      radius: 28,
      threshold: 50,
    },
    paramControls: [
      { key: 'intensity', label: 'Glow Brightness', type: 'slider', min: 10, max: 100, step: 1 },
      { key: 'radius', label: 'Diffusion Radius', type: 'slider', min: 5, max: 60, step: 1 },
      { key: 'threshold', label: 'Luma Threshold', type: 'slider', min: 0, max: 100, step: 1 },
    ],
  },
  {
    type: 'chromaticAberration',
    name: 'Easy Motion RGB Split',
    category: 'Optical & Glow',
    description: 'Displaces red and cyan optical channels along edge contours for high-energy motion.',
    badge: 'Easy Motion FX',
    defaultParams: {
      offset: 4.0,
      angle: 45,
    },
    paramControls: [
      { key: 'offset', label: 'Color Offset Px', type: 'slider', min: 1, max: 20, step: 0.5 },
      { key: 'angle', label: 'Displacement Angle', type: 'slider', min: 0, max: 360, step: 5 },
    ],
  },
  // Glitch & Distortion
  {
    type: 'rgbGlitch',
    name: 'Easy Motion Data Glitch',
    category: 'Glitch & Distortion',
    description: 'Horizontal scanline jitter, digital block compression displacement, and frame flash.',
    badge: 'Easy Motion Glitch',
    defaultParams: {
      intensity: 40,
      sliceHeight: 12,
      speed: 2.0,
    },
    paramControls: [
      { key: 'intensity', label: 'Glitch Severity', type: 'slider', min: 5, max: 100, step: 1 },
      { key: 'sliceHeight', label: 'Block Slice Size', type: 'slider', min: 4, max: 40, step: 2 },
    ],
  },
  {
    type: 'lensDistort',
    name: 'Easy Motion Lens Distortion',
    category: 'Glitch & Distortion',
    description: 'Barrel and pincushion optical curvature simulating ultra-wide curved action cameras.',
    badge: 'Easy Motion Cine',
    defaultParams: {
      curvature: 25,
      chromaZoom: 10,
    },
    paramControls: [
      { key: 'curvature', label: 'Curvature Amount', type: 'slider', min: -50, max: 50, step: 1 },
      { key: 'chromaZoom', label: 'Edge Scale', type: 'slider', min: 0, max: 30, step: 1 },
    ],
  },
  // Color & Cinema
  {
    type: 'colorGrade',
    name: 'Easy Motion Teal & Orange LUT',
    category: 'Color & Cinema',
    description: 'Blockbuster cinematic color grade with pushed cyan shadows and saturated amber highlights.',
    badge: 'Easy Motion Color',
    defaultParams: {
      lut: 'teal-orange',
      contrast: 15,
      saturation: 25,
      temperature: 10,
    },
    paramControls: [
      { key: 'contrast', label: 'Contrast Boost', type: 'slider', min: -30, max: 50, step: 1 },
      { key: 'saturation', label: 'Saturation', type: 'slider', min: -50, max: 60, step: 1 },
      { key: 'temperature', label: 'Warmth / Coolness', type: 'slider', min: -40, max: 40, step: 1 },
    ],
  },
  {
    type: 'filmBurn',
    name: 'Easy Motion Film Burn & Leaks',
    category: 'Color & Cinema',
    description: 'Organic amber and magenta light leaks flicking across the edges of the frame.',
    badge: 'Easy Motion Vintage',
    defaultParams: {
      intensity: 45,
      speed: 1.5,
    },
    paramControls: [
      { key: 'intensity', label: 'Burn Brightness', type: 'slider', min: 10, max: 100, step: 1 },
      { key: 'speed', label: 'Flicker Speed', type: 'slider', min: 0.5, max: 3.0, step: 0.1 },
    ],
  },
  {
    type: 'vignette',
    name: 'Easy Motion Radial Vignette',
    category: 'Color & Cinema',
    description: 'Soft optical darkening of the edges to focus viewer attention on center action.',
    badge: 'Easy Motion Focus',
    defaultParams: {
      radius: 65,
      softness: 40,
      darkness: 70,
    },
    paramControls: [
      { key: 'radius', label: 'Vignette Radius', type: 'slider', min: 20, max: 90, step: 1 },
      { key: 'darkness', label: 'Darkness', type: 'slider', min: 10, max: 100, step: 1 },
    ],
  },
  // Stylize & Graphic
  {
    type: 'neonEdges',
    name: 'Easy Motion Neon Edge Detect',
    category: 'Stylize & Graphic',
    description: 'Electric edge detection contours glowing on dark backgrounds.',
    badge: 'Easy Motion Stylize',
    defaultParams: {
      sensitivity: 50,
      color: '#06b6d4',
    },
    paramControls: [
      { key: 'sensitivity', label: 'Edge Sensitivity', type: 'slider', min: 10, max: 100, step: 1 },
    ],
  },
  {
    type: 'halftone',
    name: 'Easy Motion Manga Halftone',
    category: 'Stylize & Graphic',
    description: 'Comic print dot matrix raster pattern based on luminance intensity.',
    badge: 'Easy Motion Graphic',
    defaultParams: {
      dotSize: 6,
      contrast: 40,
    },
    paramControls: [
      { key: 'dotSize', label: 'Dot Grid Size', type: 'slider', min: 2, max: 20, step: 1 },
      { key: 'contrast', label: 'Dot Contrast', type: 'slider', min: 10, max: 80, step: 1 },
    ],
  },
];
