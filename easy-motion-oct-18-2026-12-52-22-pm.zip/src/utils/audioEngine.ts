/**
 * Web Audio Synthesizer & Soundtrack Manager
 * Provides real-time beat generation, audio playback synchronized with playhead,
 * and audio spectrum / beat marker detection.
 */

class AudioEngine {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private currentTrack: string = 'cyberpunk';
  private timerId: number | null = null;
  private lastScheduledBeat: number = -1;

  public init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setTrack(track: string) {
    this.currentTrack = track;
  }

  public play(currentTime: number, bpm: number = 135) {
    this.init();
    if (!this.ctx) return;
    this.isPlaying = true;
    const beatInterval = 60 / bpm;
    this.lastScheduledBeat = Math.floor(currentTime / beatInterval);

    // Schedule synthesized sounds along the current time
    const tick = () => {
      if (!this.isPlaying || !this.ctx) return;
      this.timerId = window.requestAnimationFrame(tick);
    };
    tick();
  }

  public updateTime(currentTime: number, bpm: number = 135) {
    if (!this.isPlaying || !this.ctx) return;
    const beatInterval = 60 / bpm;
    const currentBeat = Math.floor(currentTime / beatInterval);

    if (currentBeat !== this.lastScheduledBeat && currentBeat >= 0) {
      this.lastScheduledBeat = currentBeat;
      this.triggerBeatSound(currentBeat % 8);
    }
  }

  private triggerBeatSound(step: number) {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;

    // 1. Kick on 0, 4, and accent on 6
    if (step === 0 || step === 4 || step === 6) {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.frequency.setValueAtTime(140, now);
      osc.frequency.exponentialRampToValueAtTime(32, now + 0.12);
      gain.gain.setValueAtTime(0.7, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.2);
    }

    // 2. Snare / Clap on 2 and 6
    if (step === 2 || step === 6) {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(220, now);
      gain.gain.setValueAtTime(0.35, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.15);
    }

    // 3. Hi-hat on every step with varying accents
    const hat = this.ctx.createOscillator();
    const hatGain = this.ctx.createGain();
    hat.type = 'square';
    hat.frequency.setValueAtTime(6000 + (step % 2) * 2000, now);
    hatGain.gain.setValueAtTime(step % 2 === 0 ? 0.08 : 0.04, now);
    hatGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.04);
    hat.connect(hatGain);
    hatGain.connect(this.ctx.destination);
    hat.start(now);
    hat.stop(now + 0.04);

    // 4. Bass note
    if (step === 0 || step === 3 || step === 5) {
      const bass = this.ctx.createOscillator();
      const bassGain = this.ctx.createGain();
      bass.type = 'sawtooth';
      const freqs = [55, 65.4, 73.4, 49]; // A1, C2, D2, G1
      const noteFreq = freqs[Math.floor(step / 2) % freqs.length];
      bass.frequency.setValueAtTime(noteFreq, now);
      bassGain.gain.setValueAtTime(0.25, now);
      bassGain.gain.exponentialRampToValueAtTime(0.01, now + 0.28);
      bass.connect(bassGain);
      bassGain.connect(this.ctx.destination);
      bass.start(now);
      bass.stop(now + 0.28);
    }
  }

  public pause() {
    this.isPlaying = false;
    if (this.timerId) {
      cancelAnimationFrame(this.timerId);
      this.timerId = null;
    }
  }
}

export const audioEngine = new AudioEngine();
